import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Info, X, XCircle } from 'lucide-react';
import { useLocalStorage } from './hooks';

interface RecentItem { id: string; usedAt: number }
interface Toast { id: number; message: string; tone: 'success' | 'info' | 'error' }
interface HubContextValue {
  favorites: string[];
  recents: RecentItem[];
  toggleFavorite: (id: string) => void;
  addRecent: (id: string) => void;
  clearRecents: () => void;
  theme: 'light' | 'dark';
  language: 'en' | 'fa';
  toggleLanguage: () => void;
  toggleTheme: () => void;
  searchOpen: boolean;
  setSearchOpen: (open: boolean) => void;
  toast: (message: string, tone?: Toast['tone']) => void;
}

const HubContext = createContext<HubContextValue | null>(null);

export function HubProvider({ children }: { children: ReactNode }) {
  const [favorites, setFavorites] = useLocalStorage<string[]>('favorites', []);
  const [recents, setRecents] = useLocalStorage<RecentItem[]>('recents', []);
  const [theme, setTheme] = useLocalStorage<'light' | 'dark'>('theme', window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  const [language, setLanguage] = useLocalStorage<'en'|'fa'>('language', 'en');
  const [searchOpen, setSearchOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = useCallback((message: string, tone: Toast['tone'] = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((current) => [...current.slice(-2), { id, message, tone }]);
    window.setTimeout(() => setToasts((current) => current.filter((item) => item.id !== id)), 3200);
  }, []);

  const toggleFavorite = useCallback((id: string) => {
    setFavorites((current) => {
      const removing = current.includes(id);
      toast(removing ? 'Removed from favorites' : 'Saved to favorites', 'info');
      return removing ? current.filter((item) => item !== id) : [...current, id];
    });
  }, [setFavorites, toast]);

  const addRecent = useCallback((id: string) => {
    setRecents((current) => [{ id, usedAt: Date.now() }, ...current.filter((item) => item.id !== id)].slice(0, 10));
  }, [setRecents]);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'fa' ? 'rtl' : 'ltr';
    document.documentElement.classList.toggle('dark', theme === 'dark');
    document.documentElement.style.colorScheme = theme;
  }, [theme, language]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setSearchOpen((open) => !open);
      }
      if (event.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes((event.target as HTMLElement).tagName)) {
        event.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const value = useMemo<HubContextValue>(() => ({
    favorites, recents, toggleFavorite, addRecent,
    clearRecents: () => setRecents([]), theme, language, toggleLanguage: () => setLanguage((current) => current === 'fa' ? 'en' : 'fa'),
    toggleTheme: () => setTheme((current) => current === 'dark' ? 'light' : 'dark'),
    searchOpen, setSearchOpen, toast,
  }), [favorites, recents, toggleFavorite, addRecent, setRecents, theme, setTheme, searchOpen, toast, language, setLanguage]);

  return (
    <HubContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-4 bottom-4 z-[100] flex flex-col items-end gap-2 sm:left-auto sm:w-[380px]" aria-live="polite" aria-atomic="false">
        <AnimatePresence initial={false}>
          {toasts.map((item) => {
            const Icon = item.tone === 'success' ? CheckCircle2 : item.tone === 'error' ? XCircle : Info;
            return (
              <motion.div key={item.id} initial={{ opacity: 0, y: 14, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, x: 20 }} className="pointer-events-auto flex w-full items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/95 px-4 py-3 text-sm font-medium text-slate-800 shadow-xl shadow-slate-950/10 backdrop-blur-xl dark:border-white/10 dark:bg-slate-900/95 dark:text-slate-100">
                <Icon className={`h-5 w-5 shrink-0 ${item.tone === 'success' ? 'text-emerald-500' : item.tone === 'error' ? 'text-rose-500' : 'text-indigo-500'}`} />
                <span className="flex-1">{item.message}</span>
                <button onClick={() => setToasts((current) => current.filter((toastItem) => toastItem.id !== item.id))} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-white/10 dark:hover:text-white" aria-label="Dismiss notification"><X className="h-4 w-4" /></button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </HubContext.Provider>
  );
}

export function useHub() {
  const context = useContext(HubContext);
  if (!context) throw new Error('useHub must be used inside HubProvider');
  return context;
}
