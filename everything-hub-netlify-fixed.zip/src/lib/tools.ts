import {
  AlarmClock, Baseline, BookOpen, Braces, Calculator, CalendarDays, CaseSensitive,
  CheckSquare2, Clock3, Coins, Combine, Crop, FileImage, FileText, GraduationCap,
  Hash, Image, Lightbulb, ListChecks, LockKeyhole, FileCode2,
  NotebookPen, Percent, QrCode, ScanText, Sparkles, SquarePen, StopCircle,
  TextCursorInput, TextQuote, Timer, WandSparkles, Wrench,
  type LucideIcon,
} from 'lucide-react';

export type CategoryId =
  | 'productivity' | 'files' | 'image' | 'ai' | 'education'
  | 'calculators' | 'text' | 'developer' | 'time' | 'everyday';

export interface Category {
  id: CategoryId;
  name: string;
  description: string;
  icon: LucideIcon;
}

export interface ToolMeta {
  id: string;
  name: string;
  description: string;
  category: CategoryId;
  alsoIn?: CategoryId[];
  keywords: string[];
  icon: LucideIcon;
  popular?: boolean;
  featured?: boolean;
  local?: boolean;
}

export const categories: Category[] = [
  { id: 'productivity', name: 'Productivity', description: 'Plan, focus, and get things done.', icon: CheckSquare2 },
  { id: 'files', name: 'File & PDF Tools', description: 'Work with documents without uploads.', icon: FileText },
  { id: 'image', name: 'Image Tools', description: 'Resize, compress, convert, and read.', icon: Image },
  { id: 'ai', name: 'AI Tools', description: 'Private, on-device language intelligence.', icon: Sparkles },
  { id: 'education', name: 'Education', description: 'Learn, practice, and retain more.', icon: GraduationCap },
  { id: 'calculators', name: 'Calculators', description: 'Accurate answers for daily decisions.', icon: Calculator },
  { id: 'text', name: 'Text & Writing', description: 'Write, clean, inspect, and transform.', icon: SquarePen },
  { id: 'developer', name: 'Developer Tools', description: 'Practical utilities for building software.', icon: Braces },
  { id: 'time', name: 'Time & Date', description: 'Calculate, track, and make time count.', icon: Clock3 },
  { id: 'everyday', name: 'Everyday Utilities', description: 'Small tools that solve real problems.', icon: Wrench },
];

export const tools: ToolMeta[] = [
  { id: 'advanced-calculator', name: 'Advanced Calculator', description: 'Evaluate expressions with functions, memory, angles, and a reusable history.', category: 'calculators', alsoIn: ['everyday'], keywords: ['scientific', 'math', 'expression', 'sin', 'cos'], icon: Calculator, popular: true, local: true },
  { id: 'age-calculator', name: 'Age Calculator', description: 'Find an exact age in years, months, and days, plus the next birthday.', category: 'time', alsoIn: ['everyday'], keywords: ['birthday', 'birth', 'age', 'years'], icon: CalendarDays },
  { id: 'date-difference', name: 'Date Difference', description: 'Calculate calendar days, business days, and the exact span between dates.', category: 'time', alsoIn: ['calculators'], keywords: ['days', 'duration', 'between', 'business days'], icon: CalendarDays },
  { id: 'unit-converter', name: 'Unit Converter', description: 'Convert length, mass, temperature, volume, speed, data, area, and time.', category: 'calculators', alsoIn: ['everyday'], keywords: ['measurement', 'metric', 'imperial', 'temperature', 'weight'], icon: Percent, popular: true },
  { id: 'currency-converter', name: 'Currency Converter', description: 'Convert major currencies with timestamped rates and an honest offline fallback.', category: 'calculators', alsoIn: ['everyday'], keywords: ['money', 'exchange', 'forex', 'usd', 'eur'], icon: Coins, popular: true },
  { id: 'qr-code', name: 'QR Code Generator', description: 'Create crisp, customizable QR codes for links, text, contact details, or Wi-Fi.', category: 'everyday', keywords: ['barcode', 'link', 'wifi', 'scan'], icon: QrCode, popular: true, local: true },
  { id: 'password-generator', name: 'Password Generator', description: 'Generate cryptographically secure passwords with clear strength estimates.', category: 'everyday', alsoIn: ['developer'], keywords: ['secure', 'random', 'passphrase', 'security'], icon: LockKeyhole, popular: true, local: true },
  { id: 'pdf-merger', name: 'PDF Merger', description: 'Combine multiple PDFs in your chosen order entirely inside your browser.', category: 'files', keywords: ['combine', 'join', 'document', 'merge'], icon: Combine, popular: true, featured: true, local: true },
  { id: 'image-compressor', name: 'Image Compressor', description: 'Reduce image file size with live quality and dimension controls.', category: 'image', keywords: ['optimize', 'shrink', 'jpeg', 'webp', 'size'], icon: FileImage, popular: true, local: true },
  { id: 'image-resizer', name: 'Image Resizer', description: 'Resize images to exact dimensions while preserving aspect ratio.', category: 'image', keywords: ['dimensions', 'pixels', 'scale', 'crop'], icon: Crop, local: true },
  { id: 'image-converter', name: 'Image Format Converter', description: 'Convert images privately between PNG, JPEG, and WebP formats.', category: 'image', keywords: ['png', 'jpg', 'jpeg', 'webp', 'format'], icon: FileImage, local: true },
  { id: 'image-text', name: 'Text from Image (OCR)', description: 'Extract editable text from images with on-device optical character recognition.', category: 'image', alsoIn: ['ai'], keywords: ['ocr', 'extract', 'scan', 'recognition'], icon: ScanText, local: true },
  { id: 'word-counter', name: 'Word Counter', description: 'Count words, sentences, paragraphs, reading time, and frequent terms.', category: 'text', alsoIn: ['education'], keywords: ['essay', 'reading', 'count', 'writing'], icon: TextQuote, popular: true, local: true },
  { id: 'character-counter', name: 'Character Counter', description: 'Measure characters, spaces, lines, bytes, and common platform limits.', category: 'text', alsoIn: ['developer'], keywords: ['length', 'letters', 'twitter', 'sms'], icon: TextCursorInput, local: true },
  { id: 'case-converter', name: 'Text Case Converter', description: 'Switch between sentence, title, camel, snake, and eight other cases.', category: 'text', alsoIn: ['developer'], keywords: ['uppercase', 'lowercase', 'capitalize', 'camelcase'], icon: CaseSensitive, local: true },
  { id: 'text-cleaner', name: 'Text Cleaner', description: 'Remove duplicate lines, extra spaces, blank lines, and formatting noise.', category: 'text', keywords: ['whitespace', 'duplicates', 'format', 'clean'], icon: WandSparkles, local: true },
  { id: 'json-formatter', name: 'JSON Formatter', description: 'Validate, format, minify, sort, inspect, and download JSON data.', category: 'developer', keywords: ['json', 'validate', 'beautify', 'minify'], icon: Braces, popular: true, local: true },
  { id: 'markdown-previewer', name: 'Markdown Previewer', description: 'Write Markdown with a sanitized live preview and HTML export.', category: 'text', alsoIn: ['developer'], keywords: ['readme', 'md', 'html', 'preview', 'editor'], icon: FileCode2, featured: true, local: true },
  { id: 'todo-list', name: 'To-do List', description: 'Organize tasks with priorities, due dates, filters, and local saving.', category: 'productivity', keywords: ['tasks', 'checklist', 'todo', 'organize'], icon: ListChecks, popular: true, featured: true, local: true },
  { id: 'notes', name: 'Notes', description: 'Write and search multiple notes with automatic local saving.', category: 'productivity', alsoIn: ['text'], keywords: ['notebook', 'write', 'memo', 'autosave'], icon: NotebookPen, local: true },
  { id: 'pomodoro', name: 'Pomodoro Timer', description: 'Focus in customizable work and break cycles with session tracking.', category: 'productivity', alsoIn: ['time'], keywords: ['focus', 'study', '25', 'break'], icon: Timer, local: true },
  { id: 'stopwatch', name: 'Stopwatch', description: 'Measure elapsed time precisely and record unlimited laps.', category: 'time', keywords: ['timer', 'laps', 'elapsed', 'milliseconds'], icon: StopCircle },
  { id: 'countdown', name: 'Countdown Timer', description: 'Count down to a duration or a specific date with pause and alerts.', category: 'time', alsoIn: ['productivity'], keywords: ['deadline', 'event', 'alarm', 'timer'], icon: AlarmClock },
  { id: 'flashcards', name: 'Flashcard Creator', description: 'Create decks, study with spaced feedback, shuffle, and export cards.', category: 'education', keywords: ['study', 'memory', 'deck', 'learn'], icon: BookOpen, local: true },
  { id: 'basic-math', name: 'Basic Math Calculator', description: 'A clear four-function calculator with percentages and calculation steps.', category: 'calculators', alsoIn: ['education'], keywords: ['addition', 'subtract', 'multiply', 'divide', 'arithmetic'], icon: Hash },
  { id: 'study-planner', name: 'Study Planner', description: 'Plan focused study sessions by subject, date, duration, and priority.', category: 'education', alsoIn: ['productivity'], keywords: ['schedule', 'exam', 'homework', 'revision'], icon: GraduationCap, local: true },
  { id: 'quiz-generator', name: 'Quiz Generator', description: 'Turn your own study notes into editable, on-device practice questions.', category: 'education', alsoIn: ['ai'], keywords: ['questions', 'test', 'practice', 'multiple choice'], icon: Lightbulb, featured: true, local: true },
  { id: 'summarizer', name: 'Smart Summarizer', description: 'Extract the most relevant sentences from text using a transparent local algorithm.', category: 'ai', alsoIn: ['text', 'education'], keywords: ['summary', 'summarize', 'condense', 'key points'], icon: WandSparkles, featured: true, local: true },
  { id: 'readability', name: 'Readability Checker', description: 'Measure reading ease, grade level, sentence length, and complex wording.', category: 'ai', alsoIn: ['text', 'education'], keywords: ['flesch', 'grade', 'clarity', 'reading level'], icon: Baseline, local: true },
];

export const getTool = (id: string) => tools.find((tool) => tool.id === id);
export const getCategory = (id: string) => categories.find((category) => category.id === id);
export const toolsInCategory = (id: CategoryId) => tools.filter((tool) => tool.category === id || tool.alsoIn?.includes(id));
export const popularTools = tools.filter((tool) => tool.popular);
export const featuredTools = tools.filter((tool) => tool.featured);

export function filterTools(query: string) {
  const terms = query.toLowerCase().trim().split(/\s+/).filter(Boolean);
  if (!terms.length) return tools;
  return tools
    .map((tool) => {
      const categoryNames = [tool.category, ...(tool.alsoIn || [])].map((id) => getCategory(id)?.name || '').join(' ');
      const haystack = `${tool.name} ${tool.description} ${tool.keywords.join(' ')} ${categoryNames}`.toLowerCase();
      const matched = terms.every((term) => haystack.includes(term));
      const name = tool.name.toLowerCase();
      const score = terms.reduce((sum, term) => sum + (name === term ? 20 : name.startsWith(term) ? 10 : name.includes(term) ? 5 : 1), 0);
      return { tool, matched, score };
    })
    .filter((entry) => entry.matched)
    .sort((a, b) => b.score - a.score)
    .map((entry) => entry.tool);
}

export const routeForTool = (id: string) => `/tool/${id}`;
export const routeForCategory = (id: CategoryId) => `/category/${id}`;
