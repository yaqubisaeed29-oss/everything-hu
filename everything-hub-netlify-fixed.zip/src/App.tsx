import { useEffect, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { HubProvider, useHub } from './lib/hub';
import { getCategory, getTool } from './lib/tools';
import Layout from './components/Layout';
import Home from './components/Home';
import ToolWorkspace from './components/ToolWorkspace';
import { AllToolsPage, CategoriesPage, CategoryPage, FavoritesPage, NotFoundPage } from './components/Directory';
import { AboutPage, AccessibilityPage, ContactPage, FeedbackPage, PrivacyPage, TermsPage } from './components/InfoPages';

function currentPath() {
  const hash = window.location.hash;
  return hash.startsWith('#/') ? hash.slice(1).split('?')[0] : '/';
}

function RoutedApp() {
  const [path, setPath] = useState(currentPath); const { addRecent } = useHub(); const reduced = useReducedMotion();
  useEffect(() => {
    const change = () => { if (window.location.hash && !window.location.hash.startsWith('#/')) return; setPath(currentPath()); };
    window.addEventListener('hashchange', change);
    return () => window.removeEventListener('hashchange', change);
  }, []);
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
    const segments = path.split('/'); let title = 'Everything Hub — Everything You Need. All in One Place.';
    if (segments[1] === 'tool') { const tool = getTool(segments[2]); if (tool) { title = `${tool.name} — Everything Hub`; addRecent(tool.id); } }
    else if (segments[1] === 'category') { const category = getCategory(segments[2]); if (category) title = `${category.name} — Everything Hub`; }
    else if (path !== '/') { const names: Record<string, string> = { '/tools': 'All Tools', '/categories': 'Categories', '/favorites': 'Your Favorites', '/about': 'About', '/contact': 'Contact', '/feedback': 'Feedback', '/privacy': 'Privacy Policy', '/terms': 'Terms of Service', '/accessibility': 'Accessibility' }; if (names[path]) title = `${names[path]} — Everything Hub`; }
    document.title = title;
  }, [path, addRecent]);

  let page: React.ReactNode;
  if (path === '/') page = <Home />;
  else if (path === '/tools') page = <AllToolsPage />;
  else if (path === '/categories') page = <CategoriesPage />;
  else if (path === '/favorites') page = <FavoritesPage />;
  else if (path.startsWith('/tool/')) page = <ToolWorkspace id={decodeURIComponent(path.slice(6))} />;
  else if (path.startsWith('/category/')) page = <CategoryPage id={decodeURIComponent(path.slice(10))} />;
  else if (path === '/about') page = <AboutPage />;
  else if (path === '/contact') page = <ContactPage />;
  else if (path === '/feedback') page = <FeedbackPage />;
  else if (path === '/privacy') page = <PrivacyPage />;
  else if (path === '/terms') page = <TermsPage />;
  else if (path === '/accessibility') page = <AccessibilityPage />;
  else page = <NotFoundPage />;

  return <Layout path={path}><AnimatePresence mode="wait" initial={false}><motion.div key={path} initial={reduced ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={reduced ? undefined : { opacity: 0, y: -5 }} transition={{ duration: .22, ease: 'easeOut' }}>{page}</motion.div></AnimatePresence></Layout>;
}

export default function App() { return <HubProvider><RoutedApp /></HubProvider>; }
