import { useCallback, useEffect, useRef, useState, type ChangeEvent, type DragEvent } from 'react';
import { ArrowDown, ArrowUp, CheckCircle2, Download, FileText, LoaderCircle, ScanText, Trash2, UploadCloud, X } from 'lucide-react';
import { Button, CopyButton, Field, Input, Notice, Panel, Select, Textarea } from '../components/ui';
import { useHub } from '../lib/hub';
import { useObjectUrl } from '../lib/hooks';
import { canvasToBlob, cx, downloadBlob, formatBytes, loadImage, uid } from '../lib/utils';

function FilePicker({ accept, onFile, label = 'Choose an image', description = 'PNG, JPEG, or WebP · processed on your device', multiple = false }: { accept: string; onFile: (files: File[]) => void; label?: string; description?: string; multiple?: boolean }) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const drop = (event: DragEvent) => { event.preventDefault(); setDragging(false); onFile(Array.from(event.dataTransfer.files)); };
  return <div onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={drop} className={cx('flex min-h-56 flex-col items-center justify-center rounded-3xl border-2 border-dashed px-6 py-10 text-center transition', dragging ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-400/10' : 'border-slate-200 bg-slate-50/60 hover:border-indigo-300 dark:border-white/10 dark:bg-white/[.025]')}>
    <span className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-indigo-600 shadow-sm dark:bg-white/[.07] dark:text-indigo-300"><UploadCloud className="h-7 w-7" strokeWidth={1.7} /></span><h3 className="font-semibold text-slate-800 dark:text-white">Drop {multiple ? 'files' : 'a file'} here</h3><p className="mt-1 text-sm text-slate-500 dark:text-slate-400">or select from your device</p><Button variant="secondary" className="mt-5" onClick={() => inputRef.current?.click()}>{label}</Button><p className="mt-3 text-xs text-slate-400">{description}</p><input ref={inputRef} type="file" accept={accept} multiple={multiple} className="sr-only" onChange={(event: ChangeEvent<HTMLInputElement>) => { onFile(Array.from(event.target.files || [])); event.target.value = ''; }} />
  </div>;
}

interface PdfItem { id: string; file: File; name: string; size: number; pages: number; range: string }
function parsePageRange(range: string, total: number) {
  if (!range.trim()) return Array.from({ length: total }, (_, index) => index);
  const pages = new Set<number>();
  for (const part of range.split(',')) {
    const match = part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
    if (!match) throw new Error(`Invalid page range “${part.trim()}”`);
    const start = Number(match[1]); const end = Number(match[2] || match[1]);
    if (start < 1 || end < start || end > total) throw new Error(`Pages must be between 1 and ${total}`);
    for (let page = start; page <= end; page += 1) pages.add(page - 1);
  }
  return [...pages].sort((a, b) => a - b);
}
export function PDFMerger() {
  const [items, setItems] = useState<PdfItem[]>([]); const [loading, setLoading] = useState(false); const [merging, setMerging] = useState(false); const [error, setError] = useState(''); const [result, setResult] = useState<Blob | null>(null); const [filename, setFilename] = useState('merged-document'); const { toast } = useHub();
  const addFiles = async (files: File[]) => {
    const pdfs = files.filter((file) => file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf'));
    if (!pdfs.length) { setError('Choose one or more valid PDF files.'); return; }
    setLoading(true); setError(''); setResult(null);
    try {
      const { PDFDocument } = await import('pdf-lib');
      const added: PdfItem[] = [];
      for (const file of pdfs) {
        try {
          const document = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: false });
          added.push({ id: uid(), file, name: file.name, size: file.size, pages: document.getPageCount(), range: '' });
        } catch { setError(`“${file.name}” is damaged, encrypted, or not a readable PDF.`); }
      }
      setItems((current) => [...current, ...added]);
    } catch { setError('The PDF engine could not be loaded. Please try again.'); }
    finally { setLoading(false); }
  };
  const move = (index: number, direction: number) => setItems((current) => { const next = [...current]; const target = index + direction; if (target < 0 || target >= next.length) return next; [next[index], next[target]] = [next[target], next[index]]; return next; });
  const merge = async () => {
    if (!items.length) return;
    setMerging(true); setError(''); setResult(null);
    try {
      const { PDFDocument } = await import('pdf-lib'); const output = await PDFDocument.create();
      for (const item of items) {
        const source = await PDFDocument.load(await item.file.arrayBuffer()); const selected = parsePageRange(item.range, item.pages);
        const pages = await output.copyPages(source, selected); pages.forEach((page) => output.addPage(page));
      }
      if (!output.getPageCount()) throw new Error('No pages were selected.');
      const bytes = await output.save(); const blob = new Blob([bytes as BlobPart], { type: 'application/pdf' }); setResult(blob); toast(`${output.getPageCount()} pages merged successfully`);
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'The PDFs could not be merged.'); }
    finally { setMerging(false); }
  };
  return <div className="space-y-6"><FilePicker accept="application/pdf,.pdf" multiple onFile={(files) => void addFiles(files)} label="Add PDF files" description="PDF only · files never leave your device" />{loading && <Notice><LoaderCircle className="mr-2 inline h-4 w-4 animate-spin" />Reading PDF page counts…</Notice>}{error && <Notice tone="error">{error}</Notice>}{items.length > 0 && <Panel><div className="mb-5 flex items-center justify-between"><div><h3 className="font-semibold text-slate-800 dark:text-white">Merge order</h3><p className="mt-1 text-xs text-slate-400">Optional page ranges: 1-3, 5, 8-10</p></div><Button variant="ghost" size="sm" onClick={() => { setItems([]); setResult(null); }}>Clear all</Button></div><div className="space-y-3">{items.map((item, index) => <div key={item.id} className="grid gap-3 rounded-2xl border border-slate-200 p-4 sm:grid-cols-[auto_1fr_150px_auto] sm:items-center dark:border-white/10"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-50 text-rose-500 dark:bg-rose-400/10"><FileText className="h-5 w-5" /></span><div className="min-w-0"><p className="truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{item.name}</p><p className="mt-1 text-xs text-slate-400">{item.pages} pages · {formatBytes(item.size)}</p></div><Input aria-label={`Page range for ${item.name}`} placeholder="All pages" value={item.range} onChange={(event) => { setItems((current) => current.map((entry) => entry.id === item.id ? { ...entry, range: event.target.value } : entry)); setResult(null); }} /><div className="flex items-center gap-1"><Button variant="ghost" size="sm" disabled={index === 0} onClick={() => move(index, -1)} aria-label={`Move ${item.name} up`}><ArrowUp className="h-4 w-4" /></Button><Button variant="ghost" size="sm" disabled={index === items.length - 1} onClick={() => move(index, 1)} aria-label={`Move ${item.name} down`}><ArrowDown className="h-4 w-4" /></Button><Button variant="ghost" size="sm" onClick={() => { setItems((current) => current.filter((entry) => entry.id !== item.id)); setResult(null); }} aria-label={`Remove ${item.name}`}><Trash2 className="h-4 w-4" /></Button></div></div>)}</div><div className="mt-5 flex flex-col gap-3 border-t border-slate-100 pt-5 sm:flex-row dark:border-white/10"><Input value={filename} onChange={(event) => setFilename(event.target.value.replace(/\.pdf$/i, ''))} aria-label="Output filename" className="sm:max-w-xs" /><Button loading={merging} onClick={() => void merge()} className="sm:ml-auto">Merge {items.reduce((sum, item) => sum + item.pages, 0)} available pages</Button></div></Panel>}{result && <Notice tone="success" className="flex flex-col gap-3 sm:flex-row sm:items-center"><CheckCircle2 className="h-5 w-5 shrink-0" /><span className="flex-1">Your merged PDF is ready · {formatBytes(result.size)}</span><Button size="sm" onClick={() => downloadBlob(result, `${filename.trim() || 'merged-document'}.pdf`)}><Download className="h-4 w-4" /> Download PDF</Button></Notice>}</div>;
}

function useSourceImage() {
  const [file, setFile] = useState<File | null>(null); const [image, setImage] = useState<HTMLImageElement | null>(null); const [error, setError] = useState(''); const [loading, setLoading] = useState(false); const url = useObjectUrl(file);
  const select = async (files: File[]) => {
    const next = files[0]; if (!next) return;
    if (!next.type.startsWith('image/')) { setError('Choose a valid image file.'); return; }
    if (next.size > 50 * 1024 * 1024) { setError('Choose an image smaller than 50 MB.'); return; }
    setLoading(true); setError('');
    try { const decoded = await loadImage(next); setFile(next); setImage(decoded); }
    catch (caught) { setError(caught instanceof Error ? caught.message : 'Could not read this image.'); }
    finally { setLoading(false); }
  };
  return { file, image, error, setError, loading, url, select, clear: () => { setFile(null); setImage(null); setError(''); } };
}
async function renderImage(image: HTMLImageElement, width: number, height: number, type: string, quality: number) {
  const canvas = document.createElement('canvas'); canvas.width = Math.max(1, Math.round(width)); canvas.height = Math.max(1, Math.round(height));
  const context = canvas.getContext('2d'); if (!context) throw new Error('Canvas is not available in this browser.');
  context.imageSmoothingEnabled = true; context.imageSmoothingQuality = 'high';
  if (type === 'image/jpeg') { context.fillStyle = '#ffffff'; context.fillRect(0, 0, canvas.width, canvas.height); }
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  const blob = await canvasToBlob(canvas, type, quality);
  if (blob.type !== type) throw new Error(`This browser cannot export ${type.replace('image/', '').toUpperCase()}. Choose another format.`);
  return blob;
}
function ImagePreview({ source, output, originalSize, outputSize, alt = 'Processed image preview' }: { source: string; output: string; originalSize: number; outputSize?: number; alt?: string }) {
  return <div className="grid grid-cols-2 gap-3"><div><p className="mb-2 text-xs font-semibold text-slate-400">Original · {formatBytes(originalSize)}</p><div className="flex h-48 items-center justify-center overflow-hidden rounded-2xl bg-slate-100 dark:bg-white/[.05]"><img src={source} alt="Original upload" className="max-h-full max-w-full object-contain" /></div></div><div><p className="mb-2 text-xs font-semibold text-indigo-500">Result {outputSize !== undefined ? `· ${formatBytes(outputSize)}` : ''}</p><div className="flex h-48 items-center justify-center overflow-hidden rounded-2xl bg-indigo-50 dark:bg-indigo-400/10">{output ? <img src={output} alt={alt} className="max-h-full max-w-full object-contain" /> : <LoaderCircle className="h-6 w-6 animate-spin text-indigo-400" />}</div></div></div>;
}

export function ImageCompressor() {
  const source = useSourceImage(); const [quality, setQuality] = useState(.78); const [maxDimension, setMaxDimension] = useState(0); const [type, setType] = useState('image/webp'); const [result, setResult] = useState<Blob | null>(null); const [working, setWorking] = useState(false); const outputUrl = useObjectUrl(result);
  useEffect(() => { if (!source.image) { setResult(null); return; } let active = true; setWorking(true); const timer = window.setTimeout(() => { const image = source.image!; const scale = maxDimension > 0 ? Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight)) : 1; renderImage(image, image.naturalWidth * scale, image.naturalHeight * scale, type, quality).then((blob) => { if (active) setResult(blob); }).catch((caught) => { if (active) source.setError(caught.message); }).finally(() => { if (active) setWorking(false); }); }, 160); return () => { active = false; window.clearTimeout(timer); }; }, [source.image, quality, maxDimension, type]);
  if (!source.file || !source.image) return <div className="space-y-4"><FilePicker accept="image/png,image/jpeg,image/webp" onFile={(files) => void source.select(files)} />{source.error && <Notice tone="error">{source.error}</Notice>}</div>;
  const reduction = result ? Math.round((1 - result.size / source.file.size) * 100) : 0; const extension = type.split('/')[1].replace('jpeg', 'jpg');
  return <div className="space-y-6"><div className="flex items-center justify-between gap-4"><div className="min-w-0"><p className="truncate text-sm font-semibold dark:text-white">{source.file.name}</p><p className="mt-1 text-xs text-slate-400">{source.image.naturalWidth} × {source.image.naturalHeight} px</p></div><Button variant="ghost" size="sm" onClick={() => { source.clear(); setResult(null); }}><X className="h-4 w-4" /> Change image</Button></div><ImagePreview source={source.url} output={outputUrl} originalSize={source.file.size} outputSize={result?.size} /><Panel><div className="grid gap-5 sm:grid-cols-2"><Field label={`Quality · ${Math.round(quality * 100)}%`}><input type="range" min="0.1" max="1" step="0.01" value={quality} onChange={(event) => setQuality(Number(event.target.value))} className="mt-4 w-full accent-indigo-600" /></Field><Field label="Output format"><Select value={type} onChange={(event) => setType(event.target.value)}><option value="image/webp">WebP · smallest</option><option value="image/jpeg">JPEG · compatible</option><option value="image/png">PNG · lossless</option></Select></Field><Field label="Maximum width or height" hint="0 keeps original"><Input type="number" min="0" max="12000" value={maxDimension} onChange={(event) => setMaxDimension(Number(event.target.value))} /></Field><div className="flex items-end"><div className="w-full rounded-xl bg-slate-50 p-3 text-sm dark:bg-white/[.05]"><span className="text-slate-500">Size change: </span><strong className={reduction >= 0 ? 'text-emerald-600' : 'text-amber-600'}>{result ? `${reduction >= 0 ? '−' : '+'}${Math.abs(reduction)}%` : 'Calculating…'}</strong></div></div></div>{source.error && <Notice tone="error" className="mt-4">{source.error}</Notice>}<Button className="mt-5 w-full" loading={working} disabled={!result} onClick={() => result && downloadBlob(result, `${source.file!.name.replace(/\.[^.]+$/, '')}-compressed.${extension}`)}><Download className="h-4 w-4" /> Download compressed image</Button></Panel></div>;
}

export function ImageResizer() {
  const source = useSourceImage(); const [width, setWidth] = useState(0); const [height, setHeight] = useState(0); const [lock, setLock] = useState(true); const [type, setType] = useState('image/png'); const [result, setResult] = useState<Blob | null>(null); const [working, setWorking] = useState(false); const outputUrl = useObjectUrl(result);
  useEffect(() => { if (source.image) { setWidth(source.image.naturalWidth); setHeight(source.image.naturalHeight); } }, [source.image]);
  useEffect(() => { if (!source.image || width < 1 || height < 1) return; let active = true; setWorking(true); const timer = window.setTimeout(() => { renderImage(source.image!, width, height, type, .92).then((blob) => { if (active) setResult(blob); }).catch((caught) => source.setError(caught.message)).finally(() => { if (active) setWorking(false); }); }, 160); return () => { active = false; window.clearTimeout(timer); }; }, [source.image, width, height, type]);
  if (!source.file || !source.image) return <div className="space-y-4"><FilePicker accept="image/png,image/jpeg,image/webp" onFile={(files) => void source.select(files)} />{source.error && <Notice tone="error">{source.error}</Notice>}</div>;
  const ratio = source.image.naturalWidth / source.image.naturalHeight;
  const updateWidth = (value: number) => { setWidth(value); if (lock) setHeight(Math.max(1, Math.round(value / ratio))); };
  const updateHeight = (value: number) => { setHeight(value); if (lock) setWidth(Math.max(1, Math.round(value * ratio))); };
  return <div className="space-y-6"><div className="flex items-center justify-between"><p className="text-sm text-slate-500">Original: <strong className="dark:text-white">{source.image.naturalWidth} × {source.image.naturalHeight}</strong></p><Button variant="ghost" size="sm" onClick={() => { source.clear(); setResult(null); }}><X className="h-4 w-4" /> Change image</Button></div><ImagePreview source={source.url} output={outputUrl} originalSize={source.file.size} outputSize={result?.size} /><Panel><div className="mb-5 flex flex-wrap gap-2">{[25, 50, 75, 100].map((percent) => <Button key={percent} size="sm" variant="secondary" onClick={() => { updateWidth(Math.max(1, Math.round(source.image!.naturalWidth * percent / 100))); if (!lock) setHeight(Math.max(1, Math.round(source.image!.naturalHeight * percent / 100))); }}>{percent}%</Button>)}<Button size="sm" variant="secondary" onClick={() => { setLock(true); updateWidth(1920); }}>Full HD width</Button></div><div className="grid items-end gap-4 sm:grid-cols-[1fr_1fr_auto]"><Field label="Width (pixels)"><Input type="number" min="1" max="12000" value={width} onChange={(event) => updateWidth(Number(event.target.value))} /></Field><Field label="Height (pixels)"><Input type="number" min="1" max="12000" value={height} onChange={(event) => updateHeight(Number(event.target.value))} /></Field><Button variant={lock ? 'primary' : 'secondary'} onClick={() => setLock(!lock)} aria-pressed={lock}>{lock ? 'Ratio locked' : 'Ratio unlocked'}</Button></div><div className="mt-5"><Field label="Output format"><Select value={type} onChange={(event) => setType(event.target.value)}><option value="image/png">PNG</option><option value="image/jpeg">JPEG</option><option value="image/webp">WebP</option></Select></Field></div>{source.error && <Notice tone="error" className="mt-4">{source.error}</Notice>}<Button className="mt-5 w-full" loading={working} disabled={!result || width < 1 || height < 1} onClick={() => result && downloadBlob(result, `resized-${width}x${height}.${type.split('/')[1].replace('jpeg', 'jpg')}`)}><Download className="h-4 w-4" /> Download resized image</Button></Panel></div>;
}

export function ImageConverter() {
  const source = useSourceImage(); const [type, setType] = useState('image/webp'); const [quality, setQuality] = useState(.92); const [result, setResult] = useState<Blob | null>(null); const [working, setWorking] = useState(false); const outputUrl = useObjectUrl(result);
  const convert = useCallback(async () => { if (!source.image) return; setWorking(true); source.setError(''); try { setResult(await renderImage(source.image, source.image.naturalWidth, source.image.naturalHeight, type, quality)); } catch (caught) { source.setError(caught instanceof Error ? caught.message : 'Conversion failed'); } finally { setWorking(false); } }, [source.image, type, quality]);
  useEffect(() => { setResult(null); }, [type, quality, source.image]);
  if (!source.file || !source.image) return <div className="space-y-4"><FilePicker accept="image/png,image/jpeg,image/webp" onFile={(files) => void source.select(files)} />{source.error && <Notice tone="error">{source.error}</Notice>}</div>;
  return <div className="grid gap-6 lg:grid-cols-2"><Panel><div className="flex items-start justify-between"><div><p className="font-semibold dark:text-white">{source.file.name}</p><p className="mt-1 text-xs text-slate-400">{formatBytes(source.file.size)} · {source.file.type || 'image'}</p></div><Button variant="ghost" size="sm" onClick={() => { source.clear(); setResult(null); }} aria-label="Choose another image"><X className="h-4 w-4" /></Button></div><div className="mt-5 flex h-64 items-center justify-center overflow-hidden rounded-2xl bg-slate-100 dark:bg-white/[.05]"><img src={source.url} alt="Image to convert" className="max-h-full max-w-full object-contain" /></div></Panel><Panel><h3 className="font-semibold dark:text-white">Convert to</h3><div className="mt-4 grid grid-cols-3 gap-2">{[['image/webp', 'WebP'], ['image/jpeg', 'JPEG'], ['image/png', 'PNG']].map(([value, label]) => <button key={value} onClick={() => setType(value)} className={cx('rounded-xl border px-3 py-3 text-sm font-semibold transition', type === value ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-400/10 dark:text-indigo-300' : 'border-slate-200 text-slate-500 dark:border-white/10')}>{label}</button>)}</div>{type !== 'image/png' && <div className="mt-5"><Field label={`Quality · ${Math.round(quality * 100)}%`}><input type="range" min="0.1" max="1" step="0.01" value={quality} onChange={(event) => setQuality(Number(event.target.value))} className="mt-4 w-full accent-indigo-600" /></Field></div>}{type === 'image/jpeg' && <Notice className="mt-5">JPEG has no transparency. Transparent areas will become white.</Notice>}{source.error && <Notice tone="error" className="mt-4">{source.error}</Notice>}<Button className="mt-6 w-full" loading={working} onClick={() => void convert()}>Convert image</Button>{result && <div className="mt-5 rounded-2xl bg-emerald-50 p-4 dark:bg-emerald-400/10"><div className="flex items-center justify-between gap-3"><div><p className="text-sm font-semibold text-emerald-900 dark:text-emerald-200">Conversion complete</p><p className="mt-1 text-xs text-emerald-700 dark:text-emerald-300">{formatBytes(result.size)}</p></div><Button size="sm" onClick={() => downloadBlob(result, `${source.file!.name.replace(/\.[^.]+$/, '')}.${type.split('/')[1].replace('jpeg', 'jpg')}`)}><Download className="h-4 w-4" /> Download</Button></div>{outputUrl && <img src={outputUrl} alt="Converted result" className="mt-4 max-h-32 rounded-lg" />}</div>}</Panel></div>;
}

export function ImageTextExtractor() {
  const source = useSourceImage(); const [language, setLanguage] = useState('eng'); const [progress, setProgress] = useState(0); const [status, setStatus] = useState(''); const [text, setText] = useState(''); const [working, setWorking] = useState(false); const workerRef = useRef<{ terminate: () => Promise<unknown> } | null>(null);
  useEffect(() => () => { void workerRef.current?.terminate(); }, []);
  const extract = async () => {
    if (!source.file) return; setWorking(true); setProgress(0); setText(''); setStatus('Loading OCR engine'); source.setError('');
    try {
      const { createWorker, OEM } = await import('tesseract.js');
      const worker = await createWorker(language, OEM.LSTM_ONLY, { logger: (message: { status: string; progress: number }) => { setStatus(message.status.replace(/_/g, ' ')); if (Number.isFinite(message.progress)) setProgress(Math.round(message.progress * 100)); } });
      workerRef.current = worker; const response = await worker.recognize(source.file); setText(response.data.text.trim()); setStatus('Complete'); await worker.terminate(); workerRef.current = null;
    } catch (caught) { if (String(caught).includes('terminate')) setStatus('Cancelled'); else source.setError(caught instanceof Error ? caught.message : 'Text recognition failed. Try a clearer image or another language.'); }
    finally { setWorking(false); }
  };
  const cancel = async () => { await workerRef.current?.terminate(); workerRef.current = null; setWorking(false); setStatus('Cancelled'); };
  if (!source.file) return <div className="space-y-4"><FilePicker accept="image/png,image/jpeg,image/webp" onFile={(files) => void source.select(files)} label="Choose an image to scan" description="Clear, high-contrast images produce the best results" />{source.error && <Notice tone="error">{source.error}</Notice>}<Notice>Recognition runs locally. The OCR engine and selected language data are downloaded on first use, so an internet connection is required initially.</Notice></div>;
  return <div className="grid gap-6 lg:grid-cols-2"><Panel><div className="flex items-center justify-between"><p className="truncate text-sm font-semibold dark:text-white">{source.file.name}</p><Button variant="ghost" size="sm" onClick={() => { source.clear(); setText(''); }}><X className="h-4 w-4" /> Change</Button></div><div className="mt-4 flex min-h-64 items-center justify-center overflow-hidden rounded-2xl bg-slate-100 dark:bg-white/[.05]"><img src={source.url} alt="Document to scan" className="max-h-96 max-w-full object-contain" /></div><div className="mt-5 flex items-end gap-3"><Field label="Document language" className="flex-1"><Select value={language} disabled={working} onChange={(event) => setLanguage(event.target.value)}><option value="eng">English</option><option value="spa">Spanish</option><option value="fra">French</option><option value="deu">German</option><option value="por">Portuguese</option><option value="ita">Italian</option></Select></Field>{working ? <Button variant="danger" onClick={() => void cancel()}>Cancel</Button> : <Button onClick={() => void extract()}><ScanText className="h-4 w-4" /> Extract text</Button>}</div>{working && <div className="mt-5"><div className="flex justify-between text-xs text-slate-500"><span className="capitalize">{status}</span><span>{progress}%</span></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10"><div className="h-full bg-indigo-600 transition-all" style={{ width: `${progress}%` }} /></div></div>}{source.error && <Notice tone="error" className="mt-4">{source.error}</Notice>}</Panel><Panel className="flex flex-col"><div className="mb-3 flex items-center justify-between"><h3 className="font-semibold dark:text-white">Extracted text</h3><CopyButton text={text} /></div><Textarea value={text} onChange={(event) => setText(event.target.value)} placeholder={working ? 'Recognizing text…' : 'Recognized text will appear here. You can edit it before copying.'} className="min-h-80 flex-1" /><div className="mt-3 flex items-center justify-between text-xs text-slate-400"><span>{text.split(/\s+/).filter(Boolean).length} words</span>{text && <Button variant="ghost" size="sm" onClick={() => downloadBlob(new Blob([text], { type: 'text/plain' }), 'extracted-text.txt')}><Download className="h-4 w-4" /> Download .txt</Button>}</div></Panel></div>;
}
