import { useCallback, useEffect, useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { ArrowLeftRight, Delete, Download, History, RefreshCw, ShieldCheck, Wifi } from 'lucide-react';
import { Button, CopyButton, Field, Input, Notice, Panel, Select, Stat, Textarea, Toggle } from '../components/ui';
import { useHub } from '../lib/hub';
import { useLocalStorage } from '../lib/hooks';
import { clampNumber, cx, todayISO } from '../lib/utils';

// A small Pratt parser keeps calculator input safe: expressions are never eval'd.
type Token = { kind: 'number' | 'name' | 'op' | 'left' | 'right'; value: string };
function tokenizeExpression(source: string): Token[] {
  const normalized = source.replace(/[×·]/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/π/g, 'pi');
  const tokens: Token[] = [];
  let index = 0;
  while (index < normalized.length) {
    const rest = normalized.slice(index);
    const space = rest.match(/^\s+/); if (space) { index += space[0].length; continue; }
    const number = rest.match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
    if (number) { tokens.push({ kind: 'number', value: number[0] }); index += number[0].length; continue; }
    const name = rest.match(/^[a-z]+/i);
    if (name) { tokens.push({ kind: 'name', value: name[0].toLowerCase() }); index += name[0].length; continue; }
    const char = normalized[index];
    if ('+-*/%^'.includes(char)) tokens.push({ kind: 'op', value: char });
    else if (char === '(') tokens.push({ kind: 'left', value: char });
    else if (char === ')') tokens.push({ kind: 'right', value: char });
    else throw new Error(`Unexpected character “${char}”`);
    index += 1;
  }
  return tokens;
}

function evaluateExpression(source: string, degrees: boolean) {
  const tokens = tokenizeExpression(source);
  if (!tokens.length) throw new Error('Enter an expression');
  let position = 0;
  const precedence: Record<string, number> = { '+': 10, '-': 10, '*': 20, '/': 20, '%': 20, '^': 40 };
  const parse = (minimum = 0): number => {
    const token = tokens[position++];
    if (!token) throw new Error('Expression is incomplete');
    let left: number;
    if (token.kind === 'number') left = Number(token.value);
    else if (token.kind === 'left') {
      left = parse();
      if (tokens[position++]?.kind !== 'right') throw new Error('Missing closing parenthesis');
    } else if (token.kind === 'op' && (token.value === '-' || token.value === '+')) {
      left = token.value === '-' ? -parse(35) : parse(35);
    } else if (token.kind === 'name') {
      if (token.value === 'pi') left = Math.PI;
      else if (token.value === 'e') left = Math.E;
      else {
        if (tokens[position++]?.kind !== 'left') throw new Error(`Use ${token.value}(…)`);
        const argument = parse();
        if (tokens[position++]?.kind !== 'right') throw new Error('Missing closing parenthesis');
        const angle = degrees ? argument * Math.PI / 180 : argument;
        const functions: Record<string, () => number> = {
          sin: () => Math.sin(angle), cos: () => Math.cos(angle), tan: () => Math.tan(angle),
          asin: () => degrees ? Math.asin(argument) * 180 / Math.PI : Math.asin(argument),
          acos: () => degrees ? Math.acos(argument) * 180 / Math.PI : Math.acos(argument),
          atan: () => degrees ? Math.atan(argument) * 180 / Math.PI : Math.atan(argument),
          sqrt: () => Math.sqrt(argument), ln: () => Math.log(argument), log: () => Math.log10(argument),
          abs: () => Math.abs(argument), exp: () => Math.exp(argument), floor: () => Math.floor(argument),
          ceil: () => Math.ceil(argument), round: () => Math.round(argument),
        };
        if (!functions[token.value]) throw new Error(`Unknown function “${token.value}”`);
        left = functions[token.value]();
      }
    } else throw new Error('Expected a number or function');
    while (tokens[position]?.kind === 'op' && precedence[tokens[position].value] >= minimum) {
      const operator = tokens[position++].value;
      const power = precedence[operator];
      const right = parse(operator === '^' ? power : power + 1);
      if (operator === '+') left += right;
      else if (operator === '-') left -= right;
      else if (operator === '*') left *= right;
      else if (operator === '/') left /= right;
      else if (operator === '%') left %= right;
      else left **= right;
    }
    return left;
  };
  const result = parse();
  if (position !== tokens.length) throw new Error('Check the order of numbers and operators');
  if (!Number.isFinite(result)) throw new Error('Result is not a finite number');
  return Math.abs(result) < 1e-12 ? 0 : result;
}

interface Calculation { expression: string; result: string; at: number }
export function AdvancedCalculator() {
  const [expression, setExpression] = useState('sqrt(144) + 5^2');
  const [degrees, setDegrees] = useState(true);
  const [memory, setMemory] = useState(0);
  const [history, setHistory] = useLocalStorage<Calculation[]>('calculator-history', []);
  const [error, setError] = useState('');
  const [result, setResult] = useState('37');
  const calculate = useCallback(() => {
    try {
      const value = evaluateExpression(expression, degrees);
      const formatted = String(Number(value.toPrecision(12)));
      setResult(formatted); setError('');
      setHistory((items) => [{ expression, result: formatted, at: Date.now() }, ...items.filter((item) => item.expression !== expression)].slice(0, 20));
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Invalid expression'); }
  }, [expression, degrees, setHistory]);
  const append = (value: string) => { setExpression((current) => current + value); setError(''); };
  const keys = ['sin(', 'cos(', 'tan(', 'ln(', 'sqrt(', '7', '8', '9', '(', ')', '4', '5', '6', '*', '/', '1', '2', '3', '+', '-', '0', '.', 'pi', '^', '%'];
  return <div className="grid gap-6 lg:grid-cols-[minmax(0,1.25fr)_minmax(260px,.75fr)]">
    <Panel>
      <form onSubmit={(event) => { event.preventDefault(); calculate(); }}>
        <Field label="Expression" hint="Press Enter to calculate"><div className="relative"><Input autoFocus value={expression} onChange={(event) => { setExpression(event.target.value); setError(''); }} className="h-16 pr-20 font-mono text-lg" spellCheck={false} aria-describedby="calculator-help" /><Button type="button" variant="ghost" size="sm" className="absolute right-2 top-2.5" onClick={() => { setExpression(''); setResult('0'); setError(''); }}>Clear</Button></div></Field>
        <div id="calculator-help" className="mt-3 flex flex-wrap items-center justify-between gap-3"><div className="flex rounded-xl bg-slate-100 p-1 dark:bg-white/[.06]">{[true, false].map((value) => <button type="button" key={String(value)} onClick={() => setDegrees(value)} className={cx('rounded-lg px-3 py-1.5 text-xs font-semibold transition', degrees === value ? 'bg-white text-indigo-600 shadow-sm dark:bg-white/10 dark:text-indigo-300' : 'text-slate-500')}>{value ? 'Degrees' : 'Radians'}</button>)}</div><p className="text-xs text-slate-400">Functions: sin, cos, tan, asin, sqrt, log, ln, abs, exp</p></div>
        <div className="my-5 flex min-h-24 items-center justify-end overflow-x-auto rounded-2xl bg-slate-950 px-5 py-4 text-right text-3xl font-semibold tracking-tight text-white tabular-nums dark:bg-black/30 sm:text-4xl" aria-live="polite">{result}</div>
        {error && <Notice tone="error" className="mb-4">{error}</Notice>}
        <div className="grid grid-cols-5 gap-2">{keys.map((key) => <Button type="button" variant="secondary" key={key} onClick={() => append(key)} className="px-1 font-mono">{key === '*' ? '×' : key === '/' ? '÷' : key}</Button>)}<Button type="button" variant="secondary" onClick={() => setExpression((current) => current.slice(0, -1))} aria-label="Delete last character"><Delete className="h-4 w-4" /></Button><Button type="button" variant="secondary" onClick={() => append(result)}>Ans</Button><Button type="submit" className="col-span-3">Calculate</Button></div>
        <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-4 dark:border-white/10"><span className="mr-auto text-xs font-semibold text-slate-400">Memory: <span className="text-slate-700 dark:text-slate-200">{memory}</span></span>{[['MC', () => setMemory(0)], ['MR', () => append(String(memory))], ['M+', () => setMemory((value) => value + Number(result || 0))], ['M−', () => setMemory((value) => value - Number(result || 0))]].map(([label, action]) => <Button type="button" size="sm" variant="ghost" key={label as string} onClick={action as () => void}>{label as string}</Button>)}</div>
      </form>
    </Panel>
    <Panel className="flex min-h-0 flex-col"><div className="mb-4 flex items-center justify-between"><h3 className="flex items-center gap-2 font-semibold text-slate-800 dark:text-white"><History className="h-4 w-4" /> History</h3>{history.length > 0 && <Button size="sm" variant="ghost" onClick={() => setHistory([])}>Clear</Button>}</div><div className="max-h-[520px] space-y-2 overflow-y-auto">{history.length ? history.map((item) => <button key={`${item.at}-${item.expression}`} onClick={() => { setExpression(item.expression); setResult(item.result); }} className="w-full rounded-xl bg-slate-50 px-4 py-3 text-right transition hover:bg-indigo-50 dark:bg-white/[.04] dark:hover:bg-indigo-400/10"><span className="block truncate font-mono text-xs text-slate-400">{item.expression}</span><span className="mt-1 block font-mono font-semibold text-slate-800 dark:text-slate-100">= {item.result}</span></button>) : <p className="rounded-xl border border-dashed border-slate-200 p-6 text-center text-sm text-slate-400 dark:border-white/10">Completed calculations will appear here.</p>}</div></Panel>
  </div>;
}

function exactAge(from: Date, to: Date) {
  let years = to.getFullYear() - from.getFullYear();
  let months = to.getMonth() - from.getMonth();
  let days = to.getDate() - from.getDate();
  if (days < 0) { months -= 1; days += new Date(to.getFullYear(), to.getMonth(), 0).getDate(); }
  if (months < 0) { years -= 1; months += 12; }
  return { years, months, days };
}

export function AgeCalculator() {
  const [birth, setBirth] = useState('1995-01-01');
  const [asOf, setAsOf] = useState(todayISO());
  const data = useMemo(() => {
    if (!birth || !asOf) return { error: 'Choose both dates.' };
    const start = new Date(`${birth}T12:00:00`); const end = new Date(`${asOf}T12:00:00`);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return { error: 'Enter valid dates.' };
    if (start > end) return { error: 'Date of birth must be before the comparison date.' };
    const age = exactAge(start, end);
    const totalDays = Math.floor((end.getTime() - start.getTime()) / 86400000);
    let next = new Date(end.getFullYear(), start.getMonth(), start.getDate(), 12);
    if (next <= end) next = new Date(end.getFullYear() + 1, start.getMonth(), start.getDate(), 12);
    if (next.getMonth() !== start.getMonth()) next = new Date(next.getFullYear(), start.getMonth() + 1, 0, 12);
    return { age, totalDays, next, untilNext: Math.ceil((next.getTime() - end.getTime()) / 86400000), error: '' };
  }, [birth, asOf]);
  return <div className="space-y-6"><Panel><div className="grid gap-5 sm:grid-cols-2"><Field label="Date of birth"><Input type="date" value={birth} max={asOf} onChange={(event) => setBirth(event.target.value)} /></Field><Field label="Age on date" hint="Defaults to today"><Input type="date" value={asOf} onChange={(event) => setAsOf(event.target.value)} /></Field></div></Panel>{data.error ? <Notice tone="error">{data.error}</Notice> : <><div className="grid grid-cols-3 gap-3"><Stat label="Years" value={data.age!.years} /><Stat label="Months" value={data.age!.months} /><Stat label="Days" value={data.age!.days} /></div><Panel><div className="grid gap-5 sm:grid-cols-3"><div><p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total time alive</p><p className="mt-2 text-lg font-bold dark:text-white">{data.totalDays!.toLocaleString()} days</p><p className="mt-1 text-sm text-slate-500">about {(data.totalDays! * 24).toLocaleString()} hours</p></div><div><p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Next birthday</p><p className="mt-2 text-lg font-bold dark:text-white">{data.next!.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</p><p className="mt-1 text-sm text-slate-500">{data.untilNext} days to go</p></div><div><p className="text-xs font-semibold uppercase tracking-wider text-slate-400">In weeks</p><p className="mt-2 text-lg font-bold dark:text-white">{Math.floor(data.totalDays! / 7).toLocaleString()} weeks</p><p className="mt-1 text-sm text-slate-500">{data.totalDays! % 7} additional days</p></div></div></Panel></>}</div>;
}

function utcDay(value: string) { const [year, month, day] = value.split('-').map(Number); return Date.UTC(year, month - 1, day); }
export function DateDifferenceCalculator() {
  const [start, setStart] = useState(todayISO());
  const [end, setEnd] = useState(() => { const date = new Date(); date.setDate(date.getDate() + 30); return date.toISOString().slice(0, 10); });
  const [includeEnd, setIncludeEnd] = useState(false);
  const [swap, setSwap] = useState(false);
  const data = useMemo(() => {
    if (!start || !end) return null;
    const a = utcDay(start); const b = utcDay(end); const direction = a <= b ? 1 : -1;
    const days = Math.abs(Math.round((b - a) / 86400000)) + (includeEnd ? 1 : 0);
    let business = 0;
    for (let time = Math.min(a, b), count = 0; count < days; count += 1, time += 86400000) { const day = new Date(time).getUTCDay(); if (day !== 0 && day !== 6) business += 1; }
    const exact = exactAge(new Date(`${direction === 1 ? start : end}T12:00:00`), new Date(`${direction === 1 ? end : start}T12:00:00`));
    return { days, business, weekends: days - business, exact, weeks: Math.floor(days / 7), remaining: days % 7 };
  }, [start, end, includeEnd]);
  return <div className="space-y-6"><Panel><div className="grid items-end gap-4 sm:grid-cols-[1fr_auto_1fr]"><Field label="Start date"><Input type="date" value={start} onChange={(event) => setStart(event.target.value)} /></Field><Button variant="secondary" onClick={() => { setStart(end); setEnd(start); setSwap(!swap); }} aria-label="Swap dates"><ArrowLeftRight className="h-4 w-4" /></Button><Field label="End date"><Input type="date" value={end} onChange={(event) => setEnd(event.target.value)} /></Field></div><div className="mt-4"><Toggle checked={includeEnd} onChange={setIncludeEnd} label="Include the end date" description="Adds one day to the total, useful for accommodation and bookings." /></div></Panel>{data && <><div className="grid grid-cols-2 gap-3 lg:grid-cols-4"><Stat label="Total days" value={data.days.toLocaleString()} /><Stat label="Business days" value={data.business.toLocaleString()} detail="Monday–Friday" /><Stat label="Weekend days" value={data.weekends.toLocaleString()} /><Stat label="Weeks" value={`${data.weeks}w ${data.remaining}d`} /></div><Notice tone="info">The calendar span is <strong>{data.exact.years} years, {data.exact.months} months, and {data.exact.days} days</strong>. Business-day totals exclude Saturdays and Sundays; public holidays are not included.</Notice></>}</div>;
}

type UnitDefinition = { name: string; symbol: string; factor: number };
const unitGroups: Record<string, { base: string; units: Record<string, UnitDefinition> }> = {
  Length: { base: 'meter', units: { Millimeter: { name: 'Millimeter', symbol: 'mm', factor: .001 }, Centimeter: { name: 'Centimeter', symbol: 'cm', factor: .01 }, Meter: { name: 'Meter', symbol: 'm', factor: 1 }, Kilometer: { name: 'Kilometer', symbol: 'km', factor: 1000 }, Inch: { name: 'Inch', symbol: 'in', factor: .0254 }, Foot: { name: 'Foot', symbol: 'ft', factor: .3048 }, Yard: { name: 'Yard', symbol: 'yd', factor: .9144 }, Mile: { name: 'Mile', symbol: 'mi', factor: 1609.344 } } },
  Mass: { base: 'kilogram', units: { Milligram: { name: 'Milligram', symbol: 'mg', factor: .000001 }, Gram: { name: 'Gram', symbol: 'g', factor: .001 }, Kilogram: { name: 'Kilogram', symbol: 'kg', factor: 1 }, 'Metric ton': { name: 'Metric ton', symbol: 't', factor: 1000 }, Ounce: { name: 'Ounce', symbol: 'oz', factor: .028349523125 }, Pound: { name: 'Pound', symbol: 'lb', factor: .45359237 }, Stone: { name: 'Stone', symbol: 'st', factor: 6.35029318 } } },
  Temperature: { base: 'celsius', units: { Celsius: { name: 'Celsius', symbol: '°C', factor: 1 }, Fahrenheit: { name: 'Fahrenheit', symbol: '°F', factor: 1 }, Kelvin: { name: 'Kelvin', symbol: 'K', factor: 1 } } },
  Area: { base: 'square meter', units: { 'Square centimeter': { name: 'Square centimeter', symbol: 'cm²', factor: .0001 }, 'Square meter': { name: 'Square meter', symbol: 'm²', factor: 1 }, Hectare: { name: 'Hectare', symbol: 'ha', factor: 10000 }, 'Square kilometer': { name: 'Square kilometer', symbol: 'km²', factor: 1000000 }, 'Square foot': { name: 'Square foot', symbol: 'ft²', factor: .09290304 }, Acre: { name: 'Acre', symbol: 'ac', factor: 4046.8564224 }, 'Square mile': { name: 'Square mile', symbol: 'mi²', factor: 2589988.110336 } } },
  Volume: { base: 'liter', units: { Milliliter: { name: 'Milliliter', symbol: 'mL', factor: .001 }, Liter: { name: 'Liter', symbol: 'L', factor: 1 }, 'Cubic meter': { name: 'Cubic meter', symbol: 'm³', factor: 1000 }, Teaspoon: { name: 'US teaspoon', symbol: 'tsp', factor: .00492892159375 }, Tablespoon: { name: 'US tablespoon', symbol: 'tbsp', factor: .01478676478125 }, 'Fluid ounce': { name: 'US fluid ounce', symbol: 'fl oz', factor: .0295735295625 }, Cup: { name: 'US cup', symbol: 'cup', factor: .2365882365 }, Gallon: { name: 'US gallon', symbol: 'gal', factor: 3.785411784 } } },
  Speed: { base: 'meter per second', units: { 'Meters/second': { name: 'Meters per second', symbol: 'm/s', factor: 1 }, 'Kilometers/hour': { name: 'Kilometers per hour', symbol: 'km/h', factor: 1 / 3.6 }, 'Miles/hour': { name: 'Miles per hour', symbol: 'mph', factor: .44704 }, Knot: { name: 'Knot', symbol: 'kn', factor: .5144444444 }, 'Feet/second': { name: 'Feet per second', symbol: 'ft/s', factor: .3048 } } },
  Data: { base: 'byte', units: { Bit: { name: 'Bit', symbol: 'bit', factor: .125 }, Byte: { name: 'Byte', symbol: 'B', factor: 1 }, Kilobyte: { name: 'Kilobyte', symbol: 'KB', factor: 1000 }, Megabyte: { name: 'Megabyte', symbol: 'MB', factor: 1e6 }, Gigabyte: { name: 'Gigabyte', symbol: 'GB', factor: 1e9 }, Kibibyte: { name: 'Kibibyte', symbol: 'KiB', factor: 1024 }, Mebibyte: { name: 'Mebibyte', symbol: 'MiB', factor: 1048576 }, Gibibyte: { name: 'Gibibyte', symbol: 'GiB', factor: 1073741824 } } },
  Time: { base: 'second', units: { Millisecond: { name: 'Millisecond', symbol: 'ms', factor: .001 }, Second: { name: 'Second', symbol: 's', factor: 1 }, Minute: { name: 'Minute', symbol: 'min', factor: 60 }, Hour: { name: 'Hour', symbol: 'h', factor: 3600 }, Day: { name: 'Day', symbol: 'd', factor: 86400 }, Week: { name: 'Week', symbol: 'wk', factor: 604800 } } },
};
function convertTemperature(value: number, from: string, to: string) {
  const celsius = from === 'Fahrenheit' ? (value - 32) * 5 / 9 : from === 'Kelvin' ? value - 273.15 : value;
  return to === 'Fahrenheit' ? celsius * 9 / 5 + 32 : to === 'Kelvin' ? celsius + 273.15 : celsius;
}
export function UnitConverter() {
  const [group, setGroup] = useState('Length'); const [from, setFrom] = useState('Kilometer'); const [to, setTo] = useState('Mile'); const [amount, setAmount] = useState('1'); const [precision, setPrecision] = useState(6);
  const units = Object.keys(unitGroups[group].units);
  const changeGroup = (next: string) => { const nextUnits = Object.keys(unitGroups[next].units); setGroup(next); setFrom(nextUnits[0]); setTo(nextUnits[1] || nextUnits[0]); };
  const numeric = Number(amount);
  const converted = amount.trim() && Number.isFinite(numeric) ? group === 'Temperature' ? convertTemperature(numeric, from, to) : numeric * unitGroups[group].units[from].factor / unitGroups[group].units[to].factor : NaN;
  const display = Number.isFinite(converted) ? Number(converted.toPrecision(clampNumber(precision, 2, 12))).toLocaleString(undefined, { maximumSignificantDigits: precision, useGrouping: true }) : '—';
  return <div className="space-y-6"><Panel><div className="mb-6 flex gap-2 overflow-x-auto pb-2" role="tablist" aria-label="Measurement type">{Object.keys(unitGroups).map((name) => <button role="tab" aria-selected={group === name} key={name} onClick={() => changeGroup(name)} className={cx('shrink-0 rounded-xl px-4 py-2 text-sm font-semibold transition', group === name ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-white/[.06] dark:text-slate-300 dark:hover:bg-white/10')}>{name}</button>)}</div><div className="grid items-end gap-4 md:grid-cols-[1fr_1fr_auto_1fr]"><Field label="Value"><Input type="number" value={amount} onChange={(event) => setAmount(event.target.value)} className="text-lg font-semibold" /></Field><Field label="From"><Select value={from} onChange={(event) => setFrom(event.target.value)}>{units.map((unit) => <option key={unit}>{unit}</option>)}</Select></Field><Button variant="secondary" onClick={() => { setFrom(to); setTo(from); }} aria-label="Swap units"><ArrowLeftRight className="h-4 w-4" /></Button><Field label="To"><Select value={to} onChange={(event) => setTo(event.target.value)}>{units.map((unit) => <option key={unit}>{unit}</option>)}</Select></Field></div><div className="mt-7 rounded-2xl bg-indigo-50 px-5 py-6 dark:bg-indigo-400/10"><p className="text-sm font-medium text-indigo-700 dark:text-indigo-300">{amount || 0} {unitGroups[group].units[from].symbol} equals</p><p className="mt-1 break-words text-3xl font-bold tracking-tight text-indigo-950 dark:text-white sm:text-4xl">{display} <span className="text-xl font-semibold">{unitGroups[group].units[to].symbol}</span></p></div><div className="mt-5 flex items-center gap-4"><Field label="Precision" className="w-40"><Select value={precision} onChange={(event) => setPrecision(Number(event.target.value))}>{[3, 4, 6, 8, 10].map((value) => <option key={value} value={value}>{value} significant digits</option>)}</Select></Field><CopyButton className="mt-7" text={Number.isFinite(converted) ? `${display} ${unitGroups[group].units[to].symbol}` : ''} /></div></Panel><Notice tone="info">Conversions use internationally recognized definitions. Data units include both decimal (KB) and binary (KiB) standards.</Notice></div>;
}

const offlineRates: Record<string, number> = { USD: 1, EUR: .924, GBP: .789, JPY: 156.8, CAD: 1.359, AUD: 1.506, CHF: .901, CNY: 7.24, INR: 83.3, NZD: 1.637, SEK: 10.57, NOK: 10.72, DKK: 6.89, SGD: 1.345, HKD: 7.82, KRW: 1370, MXN: 17.1, BRL: 5.08, ZAR: 18.62, AED: 3.6725, PLN: 3.94, TRY: 32.2, THB: 36.6, IDR: 16200, PHP: 57.8, ILS: 3.72, CZK: 23.25, HUF: 358, RON: 4.6 };
type RateData = { rates: Record<string, number>; timestamp: number; source: string; live: boolean };
export function CurrencyConverter() {
  const [cached, setCached] = useLocalStorage<RateData | null>('currency-rates', null);
  const [data, setData] = useState<RateData>(cached || { rates: offlineRates, timestamp: Date.UTC(2024, 4, 1), source: 'Built-in offline reference (May 2024)', live: false });
  const [loading, setLoading] = useState(false); const [message, setMessage] = useState(''); const [amount, setAmount] = useState('100'); const [from, setFrom] = useState('USD'); const [to, setTo] = useState('EUR');
  const { toast } = useHub();
  const refresh = useCallback(async (quiet = false) => {
    setLoading(true); setMessage('');
    try {
      const response = await fetch('https://open.er-api.com/v6/latest/USD');
      if (!response.ok) throw new Error('Rate service unavailable');
      const json = await response.json();
      if (json.result !== 'success' || !json.rates) throw new Error('Unexpected rate response');
      const next: RateData = { rates: json.rates, timestamp: json.time_last_update_unix * 1000, source: 'ExchangeRate API (open.er-api.com)', live: true };
      setData(next); setCached(next); if (!quiet) toast('Exchange rates updated');
    } catch {
      setMessage('Live rates could not be reached. Showing the last saved rates or the dated offline reference below.');
      if (!quiet) toast('Using available offline rates', 'info');
    } finally { setLoading(false); }
  }, [setCached, toast]);
  useEffect(() => { if (!cached || Date.now() - cached.timestamp > 21600000) void refresh(true); }, []); // Refresh stale rates once on entry.
  const currencies = Object.keys(data.rates).sort(); const numeric = Number(amount); const result = Number.isFinite(numeric) ? numeric / data.rates[from] * data.rates[to] : NaN;
  return <div className="space-y-6"><Panel><div className="mb-6 flex flex-col gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 sm:flex-row sm:items-center dark:border-white/10 dark:bg-white/[.04]"><span className={cx('mt-1 h-2.5 w-2.5 shrink-0 rounded-full sm:mt-0', data.live ? 'bg-emerald-500' : 'bg-amber-500')} /><div className="flex-1"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{data.live ? 'Latest available market rates' : 'Offline reference rates'}</p><p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{data.source} · Updated {new Date(data.timestamp).toLocaleString()}</p></div><Button size="sm" variant="secondary" loading={loading} onClick={() => void refresh()}><RefreshCw className="h-4 w-4" /> Refresh rates</Button></div>{message && <Notice tone="warning" className="mb-5">{message}</Notice>}<div className="grid items-end gap-4 md:grid-cols-[1fr_1fr_auto_1fr]"><Field label="Amount"><Input type="number" min="0" value={amount} onChange={(event) => setAmount(event.target.value)} className="text-lg font-semibold" /></Field><Field label="From"><Select value={from} onChange={(event) => setFrom(event.target.value)}>{currencies.map((currency) => <option key={currency}>{currency}</option>)}</Select></Field><Button variant="secondary" onClick={() => { setFrom(to); setTo(from); }} aria-label="Swap currencies"><ArrowLeftRight className="h-4 w-4" /></Button><Field label="To"><Select value={to} onChange={(event) => setTo(event.target.value)}>{currencies.map((currency) => <option key={currency}>{currency}</option>)}</Select></Field></div><div className="mt-7 rounded-2xl bg-indigo-50 p-6 dark:bg-indigo-400/10"><p className="text-sm font-medium text-indigo-700 dark:text-indigo-300">{amount || 0} {from} =</p><p className="mt-1 text-4xl font-bold tracking-tight text-indigo-950 dark:text-white">{Number.isFinite(result) ? result.toLocaleString(undefined, { maximumFractionDigits: 2 }) : '—'} <span className="text-xl">{to}</span></p><p className="mt-2 text-xs text-indigo-600 dark:text-indigo-300">1 {from} = {(data.rates[to] / data.rates[from]).toFixed(6)} {to}</p></div></Panel><Notice tone="info">Rates are for general information, not financial advice. Banks and payment providers may apply different rates and fees.</Notice></div>;
}

export function QRCodeGenerator() {
  const [mode, setMode] = useState<'url' | 'text' | 'wifi'>('url'); const [text, setText] = useState('https://example.com'); const [ssid, setSsid] = useState(''); const [password, setPassword] = useState(''); const [security, setSecurity] = useState('WPA'); const [size, setSize] = useState(320); const [level, setLevel] = useState<'L' | 'M' | 'Q' | 'H'>('M'); const [dark, setDark] = useState('#111827'); const [light, setLight] = useState('#ffffff'); const [image, setImage] = useState(''); const [error, setError] = useState('');
  const payload = mode === 'wifi' ? `WIFI:T:${security};S:${ssid.replace(/([\\;,:"])/g, '\\$1')};P:${password.replace(/([\\;,:"])/g, '\\$1')};;` : text;
  useEffect(() => { const timer = window.setTimeout(() => { if (!payload || (mode === 'wifi' && !ssid)) { setImage(''); return; } QRCode.toDataURL(payload, { width: size, margin: 2, errorCorrectionLevel: level, color: { dark, light } }).then((url) => { setImage(url); setError(''); }).catch((caught) => { setImage(''); setError(caught instanceof Error ? caught.message : 'Could not generate QR code'); }); }, 180); return () => window.clearTimeout(timer); }, [payload, mode, ssid, size, level, dark, light]);
  return <div className="grid gap-6 lg:grid-cols-2"><Panel><div className="mb-5 flex rounded-xl bg-slate-100 p-1 dark:bg-white/[.06]">{(['url', 'text', 'wifi'] as const).map((item) => <button key={item} onClick={() => { setMode(item); setError(''); }} className={cx('flex-1 rounded-lg px-3 py-2 text-sm font-semibold capitalize transition', mode === item ? 'bg-white text-indigo-600 shadow-sm dark:bg-white/10 dark:text-indigo-300' : 'text-slate-500')}>{item === 'wifi' ? 'Wi-Fi' : item}</button>)}</div>{mode === 'wifi' ? <div className="space-y-4"><Field label="Network name (SSID)"><Input value={ssid} onChange={(event) => setSsid(event.target.value)} placeholder="My home network" /></Field><Field label="Password"><Input type="password" value={password} onChange={(event) => setPassword(event.target.value)} /></Field><Field label="Security"><Select value={security} onChange={(event) => setSecurity(event.target.value)}><option value="WPA">WPA / WPA2 / WPA3</option><option value="WEP">WEP</option><option value="nopass">Open network</option></Select></Field></div> : <Field label={mode === 'url' ? 'Website or link' : 'Text content'} hint={`${payload.length} characters`}>{mode === 'url' ? <Input type="url" value={text} onChange={(event) => setText(event.target.value)} placeholder="https://yourwebsite.com" /> : <Textarea rows={6} value={text} onChange={(event) => setText(event.target.value)} placeholder="Type the text to encode…" />}</Field>}<div className="mt-5 grid grid-cols-2 gap-4"><Field label="Error correction"><Select value={level} onChange={(event) => setLevel(event.target.value as typeof level)}><option value="L">Low · 7%</option><option value="M">Medium · 15%</option><option value="Q">Quartile · 25%</option><option value="H">High · 30%</option></Select></Field><Field label={`Size · ${size}px`}><input type="range" min="160" max="640" step="32" value={size} onChange={(event) => setSize(Number(event.target.value))} className="mt-4 w-full accent-indigo-600" /></Field><Field label="Code color"><Input type="color" value={dark} onChange={(event) => setDark(event.target.value)} className="p-1.5" /></Field><Field label="Background"><Input type="color" value={light} onChange={(event) => setLight(event.target.value)} className="p-1.5" /></Field></div></Panel><Panel className="flex flex-col items-center justify-center"><div className="flex min-h-72 w-full items-center justify-center rounded-2xl bg-[linear-gradient(45deg,#f1f5f9_25%,transparent_25%),linear-gradient(-45deg,#f1f5f9_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#f1f5f9_75%),linear-gradient(-45deg,transparent_75%,#f1f5f9_75%)] bg-[length:20px_20px] bg-[position:0_0,0_10px,10px_-10px,-10px_0px] p-6 dark:bg-slate-800">{image ? <img src={image} alt="Generated QR code" className="max-h-80 max-w-full rounded-lg shadow-lg" /> : <div className="text-center"><Wifi className="mx-auto mb-3 h-8 w-8 text-slate-300" /><p className="text-sm text-slate-500 dark:text-slate-400">Enter content to create your QR code.</p></div>}</div>{error && <Notice tone="error" className="mt-4 w-full">{error}</Notice>}<Button className="mt-5 w-full" disabled={!image} onClick={() => { const link = document.createElement('a'); link.href = image; link.download = 'everything-hub-qr.png'; link.click(); }}><Download className="h-4 w-4" /> Download PNG</Button><p className="mt-3 text-center text-xs text-slate-400">Test the downloaded code with your own scanner before printing.</p></Panel></div>;
}

const passwordSets = { lowercase: 'abcdefghijklmnopqrstuvwxyz', uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', numbers: '0123456789', symbols: '!@#$%^&*()_+-=[]{};:,.<>?/~' };
type PasswordSettings = { length: number; lowercase: boolean; uppercase: boolean; numbers: boolean; symbols: boolean; ambiguous: boolean; repeats: boolean };
function secureIndex(max: number) { if (max <= 1) return 0; const limit = Math.floor(256 / max) * max; const bytes = new Uint8Array(1); do crypto.getRandomValues(bytes); while (bytes[0] >= limit); return bytes[0] % max; }
function secureShuffle(items: string[]) { for (let index = items.length - 1; index > 0; index -= 1) { const target = secureIndex(index + 1); [items[index], items[target]] = [items[target], items[index]]; } return items; }
export function PasswordGenerator() {
  const [settings, setSettings] = useLocalStorage<PasswordSettings>('password-settings', { length: 20, lowercase: true, uppercase: true, numbers: true, symbols: true, ambiguous: true, repeats: true });
  const [password, setPassword] = useState('');
  const selected = Object.keys(passwordSets).filter((key) => settings[key as keyof typeof passwordSets & keyof PasswordSettings]);
  const generate = useCallback(() => {
    const groups = selected.map((key) => passwordSets[key as keyof typeof passwordSets].split('').filter((char) => settings.ambiguous || !'Il1O0o'.includes(char)));
    const pool = [...new Set(groups.flat())];
    if (!pool.length || groups.some((group) => !group.length)) { setPassword(''); return; }
    const chars: string[] = [];
    groups.forEach((group) => chars.push(group[secureIndex(group.length)]));
    while (chars.length < settings.length) { const available = settings.repeats ? pool : pool.filter((char) => !chars.includes(char)); if (!available.length) break; chars.push(available[secureIndex(available.length)]); }
    setPassword(secureShuffle(chars).join(''));
  }, [selected.join(','), settings]);
  useEffect(() => { generate(); }, [generate]);
  const poolSize = new Set(selected.flatMap((key) => passwordSets[key as keyof typeof passwordSets].split('').filter((char) => settings.ambiguous || !'Il1O0o'.includes(char)))).size; const entropy = Math.round(password.length * Math.log2(Math.max(2, poolSize))); const strength = entropy >= 100 ? 'Excellent' : entropy >= 70 ? 'Strong' : entropy >= 50 ? 'Good' : 'Weak';
  const update = <K extends keyof PasswordSettings>(key: K, value: PasswordSettings[K]) => setSettings((current) => ({ ...current, [key]: value }));
  return <div className="grid gap-6 lg:grid-cols-[1.1fr_.9fr]"><Panel><Field label="Your generated password" hint="Never stored"><div className="relative"><Input readOnly value={password} className="h-16 pr-14 font-mono text-base sm:text-lg" aria-label="Generated password" /><CopyButton text={password} label="" className="absolute right-2 top-2.5" /></div></Field><div className="mt-4"><div className="flex items-center justify-between text-xs"><span className="font-semibold text-slate-600 dark:text-slate-300">{strength}</span><span className="text-slate-400">≈ {entropy} bits of entropy</span></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10"><div className={cx('h-full rounded-full transition-all duration-500', entropy >= 100 ? 'bg-emerald-500' : entropy >= 70 ? 'bg-indigo-500' : entropy >= 50 ? 'bg-amber-500' : 'bg-rose-500')} style={{ width: `${Math.min(100, entropy / 1.2)}%` }} /></div></div><Button onClick={generate} className="mt-6 w-full" disabled={!selected.length}><RefreshCw className="h-4 w-4" /> Generate new password</Button><div className="mt-6"><div className="flex items-center justify-between"><label htmlFor="password-length" className="text-sm font-semibold dark:text-slate-200">Password length</label><span className="rounded-lg bg-slate-100 px-2.5 py-1 font-mono text-sm dark:bg-white/10 dark:text-white">{settings.length}</span></div><input id="password-length" type="range" min="8" max="64" value={settings.length} onChange={(event) => update('length', Number(event.target.value))} className="mt-4 w-full accent-indigo-600" /><div className="flex justify-between text-xs text-slate-400"><span>8</span><span>64</span></div></div></Panel><Panel><h3 className="mb-3 font-semibold text-slate-800 dark:text-white">Character options</h3>{(['lowercase', 'uppercase', 'numbers', 'symbols'] as const).map((key) => <Toggle key={key} checked={settings[key]} onChange={(value) => update(key, value)} label={{ lowercase: 'Lowercase letters', uppercase: 'Uppercase letters', numbers: 'Numbers', symbols: 'Symbols' }[key]} description={{ lowercase: 'a – z', uppercase: 'A – Z', numbers: '0 – 9', symbols: '! @ # $ % & more' }[key]} />)}<div className="my-3 border-t border-slate-100 dark:border-white/10" /><Toggle checked={!settings.ambiguous} onChange={(value) => update('ambiguous', !value)} label="Exclude ambiguous characters" description="Omits I, l, 1, O, 0, and o" /><Toggle checked={!settings.repeats} onChange={(value) => update('repeats', !value)} label="No repeated characters" description="May reduce the maximum possible length" />{!selected.length && <Notice tone="error" className="mt-4">Select at least one character type.</Notice>}{!settings.repeats && password.length < settings.length && <Notice tone="warning" className="mt-4">The selected character pool contains {poolSize} unique characters, so this no-repeat password is {password.length} characters long.</Notice>}<div className="mt-5 flex gap-3 rounded-2xl bg-emerald-50 p-4 text-emerald-900 dark:bg-emerald-400/10 dark:text-emerald-200"><ShieldCheck className="h-5 w-5 shrink-0" /><p className="text-xs leading-5">Generated with your browser’s cryptographic random number generator. Passwords are never saved or transmitted.</p></div></Panel></div>;
}
