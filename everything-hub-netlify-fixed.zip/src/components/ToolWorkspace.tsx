import type { ComponentType } from 'react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { getCategory, getTool, routeForCategory, toolsInCategory } from '../lib/tools';
import { AdvancedCalculator, AgeCalculator, CurrencyConverter, DateDifferenceCalculator, PasswordGenerator, QRCodeGenerator, UnitConverter } from '../tools/EverydayTools';
import { ImageCompressor, ImageConverter, ImageResizer, ImageTextExtractor, PDFMerger } from '../tools/FileTools';
import { CaseConverter, CharacterCounter, JSONFormatter, MarkdownPreviewer, TextCleaner, WordCounter } from '../tools/TextTools';
import { CountdownTimer, Notes, PomodoroTimer, Stopwatch, TodoList } from '../tools/ProductivityTools';
import { BasicMathCalculator, FlashcardCreator, QuizGenerator, StudyPlanner } from '../tools/EducationTools';
import { ReadabilityChecker, SmartSummarizer } from '../tools/AITools';
import { FavoriteButton, ToolCard } from './ui';

const components: Record<string, ComponentType> = {
  'advanced-calculator': AdvancedCalculator, 'age-calculator': AgeCalculator, 'date-difference': DateDifferenceCalculator,
  'unit-converter': UnitConverter, 'currency-converter': CurrencyConverter, 'qr-code': QRCodeGenerator,
  'password-generator': PasswordGenerator, 'pdf-merger': PDFMerger, 'image-compressor': ImageCompressor,
  'image-resizer': ImageResizer, 'image-converter': ImageConverter, 'image-text': ImageTextExtractor,
  'word-counter': WordCounter, 'character-counter': CharacterCounter, 'case-converter': CaseConverter,
  'text-cleaner': TextCleaner, 'json-formatter': JSONFormatter, 'markdown-previewer': MarkdownPreviewer,
  'todo-list': TodoList, notes: Notes, pomodoro: PomodoroTimer, stopwatch: Stopwatch, countdown: CountdownTimer,
  flashcards: FlashcardCreator, 'basic-math': BasicMathCalculator, 'study-planner': StudyPlanner,
  'quiz-generator': QuizGenerator, summarizer: SmartSummarizer, readability: ReadabilityChecker,
};

export default function ToolWorkspace({ id }: { id: string }) {
  const tool = getTool(id);
  if (!tool) return <div className="mx-auto max-w-3xl px-4 py-24 text-center"><h1 className="text-3xl font-bold dark:text-white">Tool not found</h1><p className="mt-3 text-slate-500">This tool may have moved. Browse the complete directory to find what you need.</p><a href="#/tools" className="mt-6 inline-flex rounded-xl bg-indigo-600 px-5 py-3 font-semibold text-white">Browse all tools</a></div>;
  const Component = components[id]; const Icon = tool.icon; const category = getCategory(tool.category)!; const related = toolsInCategory(tool.category).filter((item) => item.id !== id).slice(0, 3);
  return <div className="min-h-screen pb-20 pt-8 sm:pt-12"><div className="mx-auto max-w-[1240px] px-4 sm:px-6 lg:px-8"><div className="mb-7 flex items-center gap-2 text-xs font-medium text-slate-400"><a href="#/tools" className="flex items-center gap-1.5 rounded-md hover:text-indigo-600"><ArrowLeft className="h-3.5 w-3.5" /> All tools</a><span>/</span><a href={`#${routeForCategory(tool.category)}`} className="rounded-md hover:text-indigo-600">{category.name}</a></div><header className="mb-8 flex items-start gap-4 sm:mb-10"><span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/20 sm:h-14 sm:w-14"><Icon className="h-6 w-6 sm:h-7 sm:w-7" strokeWidth={1.7} /></span><div className="min-w-0 flex-1"><div className="flex items-start justify-between gap-3"><h1 className="text-balance text-2xl font-bold tracking-[-.035em] text-slate-950 sm:text-4xl dark:text-white">{tool.name}</h1><FavoriteButton id={id} className="border-slate-200 bg-white dark:border-white/10 dark:bg-white/[.04]" /></div><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500 sm:text-base dark:text-slate-400">{tool.description}</p>{tool.local && <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 dark:bg-emerald-400/10 dark:text-emerald-300"><ShieldCheck className="h-3.5 w-3.5" /> Private by design · your work stays on this device</p>}</div></header><main aria-label={`${tool.name} workspace`}><Component /></main>{related.length > 0 && <section className="mt-16 border-t border-slate-200/80 pt-10 dark:border-white/10"><div className="mb-5 flex items-end justify-between"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-indigo-500">Keep going</p><h2 className="mt-1 text-xl font-bold tracking-tight dark:text-white">Related tools</h2></div><a href="#/tools" className="text-sm font-semibold text-indigo-600 hover:text-indigo-500 dark:text-indigo-400">View all 29</a></div><div className="grid gap-4 md:grid-cols-3">{related.map((item) => <ToolCard key={item.id} tool={item} compact />)}</div></section>}</div></div>;
}
