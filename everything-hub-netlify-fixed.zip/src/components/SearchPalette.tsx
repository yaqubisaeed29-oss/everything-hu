import { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, Clock3, Search } from 'lucide-react';
import { filterTools, getTool, type ToolMeta } from '../lib/tools';
import { useHub } from '../lib/hub';
import { EmptyState } from './ui';

export default function SearchPalette() {
  const { searchOpen, setSearchOpen, recents } = useHub();
  const [query, setQuery] = useState('');
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const results = useMemo(() => filterTools(query).slice(0, 9), [query]);
  const recentTools = useMemo(() => recents.map((item) => getTool(item.id)).filter((tool): tool is ToolMeta => Boolean(tool)).slice(0, 5), [recents]);
  const shown = query ? results : recentTools.length ? recentTools : results.slice(0, 6);

  useEffect(() => {
    if (searchOpen) {
      setQuery(''); setActive(0);
      window.setTimeout(() => inputRef.current?.focus(), 40);
      document.body.style.overflow = 'hidden';
      const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') setSearchOpen(false); };
      window.addEventListener('keydown', escape);
      return () => { window.removeEventListener('keydown', escape); document.body.style.overflow = ''; };
    } else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [searchOpen]);
  useEffect(() => setActive(0), [query]);

  const openTool = (id: string) => {
    window.location.hash = `/tool/${id}`;
    setSearchOpen(false);
  };

  return <AnimatePresence>
    {searchOpen && <motion.div className="fixed inset-0 z-[90] flex items-start justify-center bg-slate-950/40 px-4 pt-[10vh] backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(event) => { if (event.target === event.currentTarget) setSearchOpen(false); }}>
      <motion.div role="dialog" aria-modal="true" aria-label="Search all tools" className="w-full max-w-2xl overflow-hidden rounded-3xl border border-white/20 bg-white shadow-2xl shadow-slate-950/25 dark:border-white/10 dark:bg-slate-900" initial={{ opacity: 0, y: -12, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8, scale: .98 }} transition={{ type: 'spring', stiffness: 420, damping: 32 }}>
        <div className="flex items-center gap-3 border-b border-slate-100 px-5 dark:border-white/10"><Search className="h-5 w-5 shrink-0 text-slate-400" /><input ref={inputRef} value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => {
          if (event.key === 'Escape') setSearchOpen(false);
          if (event.key === 'ArrowDown') { event.preventDefault(); setActive((value) => Math.min(shown.length - 1, value + 1)); }
          if (event.key === 'ArrowUp') { event.preventDefault(); setActive((value) => Math.max(0, value - 1)); }
          if (event.key === 'Enter' && shown[active]) openTool(shown[active].id);
        }} className="h-16 min-w-0 flex-1 bg-transparent text-base text-slate-900 outline-none placeholder:text-slate-400 dark:text-white" placeholder="What would you like to do today?" aria-label="Search tools" /><button onClick={() => setSearchOpen(false)} className="rounded-lg border border-slate-200 px-2 py-1 text-xs font-medium text-slate-400 hover:text-slate-700 dark:border-white/10 dark:hover:text-white" aria-label="Close search">Esc</button></div>
        <div className="max-h-[55vh] overflow-y-auto p-2">
          <p className="px-3 pb-2 pt-2 text-[11px] font-bold uppercase tracking-[.14em] text-slate-400">{query ? `${results.length} matching tools` : recentTools.length ? 'Recently used' : 'Suggested tools'}</p>
          {shown.length ? shown.map((tool, index) => { const Icon = tool.icon; return <button key={tool.id} onMouseEnter={() => setActive(index)} onClick={() => openTool(tool.id)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition ${active === index ? 'bg-indigo-50 dark:bg-indigo-400/10' : 'hover:bg-slate-50 dark:hover:bg-white/5'}`}><span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${active === index ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500 dark:bg-white/[.07] dark:text-slate-400'}`}><Icon className="h-4 w-4" /></span><span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-slate-800 dark:text-slate-100">{tool.name}</span><span className="block truncate text-xs text-slate-400">{tool.description}</span></span><ArrowRight className={`h-4 w-4 ${active === index ? 'text-indigo-500' : 'text-transparent'}`} /></button>; }) : <EmptyState title="No tools found" description="Try a broader phrase such as “image”, “time”, or “write”." />}
        </div>
        <div className="flex items-center justify-between border-t border-slate-100 bg-slate-50/70 px-5 py-3 text-[11px] text-slate-400 dark:border-white/10 dark:bg-white/[.025]"><span className="flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5" /> Your recent tools stay on this device</span><span>↑ ↓ to navigate · Enter to open</span></div>
      </motion.div>
    </motion.div>}
  </AnimatePresence>;
}
