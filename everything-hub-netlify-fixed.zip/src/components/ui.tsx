import { forwardRef, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react';
import { ArrowUpRight, Check, Copy, Heart, SearchX } from 'lucide-react';
import { motion } from 'framer-motion';
import type { Category, ToolMeta } from '../lib/tools';
import { routeForCategory, routeForTool, toolsInCategory } from '../lib/tools';
import { cx } from '../lib/utils';
import { useCopy } from '../lib/hooks';
import { useHub } from '../lib/hub';
import { tr } from '../lib/i18n';

export const focusRing = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2 focus-visible:ring-offset-white dark:focus-visible:ring-offset-slate-950';

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; size?: 'sm' | 'md' | 'lg'; loading?: boolean };
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button({ className, variant = 'primary', size = 'md', loading, children, disabled, ...props }, ref) {
  const styles = {
    primary: 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/20 hover:bg-indigo-500 active:bg-indigo-700 border border-indigo-600',
    secondary: 'bg-white text-slate-700 border border-slate-200 shadow-sm hover:border-slate-300 hover:bg-slate-50 dark:bg-white/[.06] dark:text-slate-200 dark:border-white/10 dark:hover:bg-white/10',
    ghost: 'bg-transparent text-slate-600 border border-transparent hover:bg-slate-100 hover:text-slate-950 dark:text-slate-400 dark:hover:bg-white/[.07] dark:hover:text-white',
    danger: 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 dark:bg-rose-500/10 dark:text-rose-300 dark:border-rose-500/20',
  };
  const sizes = { sm: 'min-h-9 px-3 py-1.5 text-xs rounded-xl', md: 'min-h-11 px-4 py-2.5 text-sm rounded-xl', lg: 'min-h-12 px-5 py-3 text-sm rounded-2xl' };
  return <button ref={ref} disabled={disabled || loading} className={cx('inline-flex shrink-0 items-center justify-center gap-2 font-semibold transition-all duration-200 active:scale-[.98] disabled:cursor-not-allowed disabled:opacity-50', focusRing, styles[variant], sizes[size], className)} {...props}>
    {loading && <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-r-transparent" aria-hidden="true" />}
    {children}
  </button>;
});

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(function Input({ className, ...props }, ref) {
  return <input ref={ref} className={cx('min-h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 shadow-sm outline-none transition placeholder:text-slate-400 hover:border-slate-300 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 dark:border-white/10 dark:bg-white/[.05] dark:text-white dark:hover:border-white/20 dark:focus:border-indigo-400', className)} {...props} />;
});

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(function Textarea({ className, ...props }, ref) {
  return <textarea ref={ref} className={cx('w-full resize-y rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm leading-6 text-slate-900 shadow-sm outline-none transition placeholder:text-slate-400 hover:border-slate-300 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 dark:border-white/10 dark:bg-white/[.05] dark:text-white dark:hover:border-white/20 dark:focus:border-indigo-400', className)} {...props} />;
});

export function Select({ className, children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className={cx('min-h-11 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 shadow-sm outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 dark:border-white/10 dark:bg-slate-900 dark:text-white', className)} {...props}>{children}</select>;
}

export function Field({ label, hint, children, className }: { label: string; hint?: string; children: ReactNode; className?: string }) {
  return <label className={cx('block space-y-2', className)}><span className="flex items-center justify-between gap-3 text-sm font-semibold text-slate-700 dark:text-slate-300">{label}{hint && <span className="text-xs font-normal text-slate-400">{hint}</span>}</span>{children}</label>;
}

export function Panel({ children, className, as: Element = 'section' }: { children: ReactNode; className?: string; as?: 'section' | 'div' | 'form' }) {
  return <Element className={cx('rounded-3xl border border-slate-200/80 bg-white p-5 shadow-[0_1px_2px_rgba(15,23,42,.03)] sm:p-6 dark:border-white/10 dark:bg-white/[.035]', className)}>{children}</Element>;
}

export function SectionHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="mb-7 flex items-end justify-between gap-5"><div className="max-w-2xl">{eyebrow && <p className="mb-2 text-xs font-bold uppercase tracking-[.16em] text-indigo-600 dark:text-indigo-400">{eyebrow}</p>}<h2 className="text-balance text-2xl font-bold tracking-[-.035em] text-slate-950 sm:text-3xl dark:text-white">{title}</h2>{description && <p className="mt-2 text-sm leading-6 text-slate-500 sm:text-base dark:text-slate-400">{description}</p>}</div>{action}</div>;
}

export function Toggle({ checked, onChange, label, description }: { checked: boolean; onChange: (checked: boolean) => void; label: string; description?: string }) {
  return <label className="flex cursor-pointer items-center justify-between gap-4 py-2"><span><span className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</span>{description && <span className="mt-0.5 block text-xs leading-5 text-slate-400">{description}</span>}</span><input type="checkbox" className="peer sr-only" checked={checked} onChange={(event) => onChange(event.target.checked)} /><span className={cx('relative h-6 w-11 shrink-0 rounded-full bg-slate-200 transition peer-focus-visible:ring-2 peer-focus-visible:ring-indigo-500 peer-focus-visible:ring-offset-2 dark:bg-white/15', checked && '!bg-indigo-600')}><span className={cx('absolute left-1 top-1 h-4 w-4 rounded-full bg-white shadow transition-transform', checked && 'translate-x-5')} /></span></label>;
}

export function Notice({ children, tone = 'info', className }: { children: ReactNode; tone?: 'info' | 'success' | 'warning' | 'error'; className?: string }) {
  const styles = { info: 'border-indigo-200 bg-indigo-50 text-indigo-800 dark:border-indigo-400/20 dark:bg-indigo-400/10 dark:text-indigo-200', success: 'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-400/20 dark:bg-emerald-400/10 dark:text-emerald-200', warning: 'border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-400/20 dark:bg-amber-400/10 dark:text-amber-200', error: 'border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-400/20 dark:bg-rose-400/10 dark:text-rose-200' };
  return <div role={tone === 'error' ? 'alert' : 'status'} className={cx('rounded-xl border px-4 py-3 text-sm leading-6', styles[tone], className)}>{children}</div>;
}

export function CopyButton({ text, label = 'Copy', disabled = false, className }: { text: string; label?: string; disabled?: boolean; className?: string }) {
  const { copied, copy } = useCopy();
  const { toast } = useHub();
  return <Button variant="secondary" size="sm" disabled={disabled || !text} className={className} onClick={async () => { await copy(text); toast('Copied to clipboard'); }}>{copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}{copied ? 'Copied' : label}</Button>;
}

export function EmptyState({ title = 'Nothing here yet', description, action }: { title?: string; description: string; action?: ReactNode }) {
  return <div className="flex min-h-48 flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 px-6 py-10 text-center dark:border-white/10"><SearchX className="mb-3 h-7 w-7 text-slate-300 dark:text-slate-600" /><h3 className="font-semibold text-slate-800 dark:text-slate-200">{title}</h3><p className="mt-1 max-w-sm text-sm leading-6 text-slate-500 dark:text-slate-400">{description}</p>{action && <div className="mt-4">{action}</div>}</div>;
}

export function FavoriteButton({ id, className }: { id: string; className?: string }) {
  const { favorites, toggleFavorite } = useHub();
  const active = favorites.includes(id);
  return <button onClick={(event) => { event.preventDefault(); event.stopPropagation(); toggleFavorite(id); }} className={cx('inline-flex h-9 w-9 items-center justify-center rounded-xl border border-transparent text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-white/10 dark:hover:text-white', focusRing, active && 'text-indigo-600 dark:text-indigo-400', className)} aria-label={active ? 'Remove from favorites' : 'Add to favorites'} aria-pressed={active}><Heart className={cx('h-[18px] w-[18px]', active && 'fill-current')} /></button>;
}

export function ToolCard({ tool, compact = false }: { tool: ToolMeta; compact?: boolean }) {
  const Icon = tool.icon; const { language } = useHub();
  return <motion.article layout className={cx('group relative overflow-hidden rounded-2xl border border-slate-200/80 bg-white transition duration-300 hover:-translate-y-0.5 hover:border-indigo-200 hover:shadow-[0_16px_40px_-20px_rgba(79,70,229,.28)] dark:border-white/10 dark:bg-white/[.035] dark:hover:border-indigo-400/30', compact ? 'p-4' : 'p-5')}>
    <div className="flex items-start gap-3.5">
      <a href={`#${routeForTool(tool.id)}`} className={cx('flex shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 transition group-hover:bg-indigo-600 group-hover:text-white dark:bg-indigo-400/10 dark:text-indigo-300 dark:group-hover:bg-indigo-500', focusRing, compact ? 'h-10 w-10' : 'h-11 w-11')} aria-label={`Open ${tool.name}`}><Icon className="h-5 w-5" strokeWidth={1.8} /></a>
      <div className="min-w-0 flex-1"><div className="flex items-start justify-between gap-1"><a href={`#${routeForTool(tool.id)}`} className={cx('font-semibold tracking-[-.015em] text-slate-900 hover:text-indigo-600 dark:text-white dark:hover:text-indigo-300', focusRing, compact ? 'text-sm' : 'text-[15px]')}>{tr(tool.name, language)}</a><FavoriteButton id={tool.id} className="-mr-2 -mt-2 h-8 w-8 opacity-60 group-hover:opacity-100 focus:opacity-100" /></div>{!compact && <p className="mt-1.5 line-clamp-2 text-sm leading-5 text-slate-500 dark:text-slate-400">{tr(tool.description, language)}</p>}</div>
    </div>
    {!compact && <a href={`#${routeForTool(tool.id)}`} className={cx('mt-4 inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 opacity-0 transition group-hover:opacity-100 focus:opacity-100 dark:text-indigo-400', focusRing)}>{tr('Open tool', language)} <ArrowUpRight className="h-3.5 w-3.5" /></a>}
  </motion.article>;
}

export function CategoryCard({ category }: { category: Category }) {
  const Icon = category.icon; const { language } = useHub();
  const count = toolsInCategory(category.id).length;
  return <a href={`#${routeForCategory(category.id)}`} className={cx('group flex min-h-36 flex-col justify-between rounded-2xl border border-slate-200/80 bg-white p-5 transition duration-300 hover:-translate-y-1 hover:border-indigo-200 hover:shadow-lg hover:shadow-slate-900/5 dark:border-white/10 dark:bg-white/[.035] dark:hover:border-indigo-400/30', focusRing)}><div className="flex items-start justify-between"><Icon className="h-6 w-6 text-indigo-600 transition-transform duration-300 group-hover:scale-110 dark:text-indigo-400" strokeWidth={1.7} /><span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-500 dark:bg-white/[.07] dark:text-slate-400">{count} {language === 'fa' ? 'ابزار' : 'tools'}</span></div><div><h3 className="font-semibold text-slate-900 dark:text-white">{tr(category.name, language)}</h3><p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">{tr(category.description, language)}</p></div></a>;
}

export function Stat({ label, value, detail }: { label: string; value: ReactNode; detail?: string }) {
  return <div className="rounded-2xl bg-slate-50 p-4 dark:bg-white/[.045]"><p className="text-xs font-medium text-slate-500 dark:text-slate-400">{label}</p><p className="mt-1.5 break-words text-xl font-bold tracking-tight text-slate-900 tabular-nums dark:text-white">{value}</p>{detail && <p className="mt-1 text-xs text-slate-400">{detail}</p>}</div>;
}
